#!/usr/bin/env python3
"""
GBOC 14.6.0 - Report Generator Engine
Generates HTML/PDF reports for backup operations, SLA, capacity, executive summary.
"""

import logging
import io
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


try:
    from version_control import __version__ as GBOC_VERSION
except Exception:
    GBOC_VERSION = "14.8.1"

def _get_core():
    from shared_core import get_shared_core
    return get_shared_core()


def _is_sqlite(conn) -> bool:
    return not hasattr(conn, 'status') and 'sqlite' in type(conn).__module__.lower()


def _detect_exec_table(conn) -> str:
    """Detecta se a tabela disponível é task_executions ou backups."""
    cur = conn.cursor()
    try:
        if _is_sqlite(conn):
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('task_executions', 'backups')")
            rows = [r[0] for r in cur.fetchall()]
        else:
            cur.execute("SELECT table_name FROM information_schema.tables WHERE table_name IN ('task_executions', 'backups')")
            rows = [r[0] for r in cur.fetchall()]
        if 'backups' in rows:
            return 'backups'
        if 'task_executions' in rows:
            return 'task_executions'
    except Exception as e:
        logger.warning(f"[REPORTS] Falha ao detectar tabela de execuções: {e}")
    return 'backups'


def _query(sql: str, params: tuple = ()) -> List[Dict]:
    core = _get_core()
    try:
        with core.get_db_connection() as conn:
            cursor = conn.cursor()
            # Ajustar placeholders de bind conforme tipo do banco
            is_sq = _is_sqlite(conn)
            adapted_sql = sql
            if is_sq and "%s" in adapted_sql:
                adapted_sql = adapted_sql.replace("%s", "?")
            elif not is_sq and "?" in adapted_sql:
                adapted_sql = adapted_sql.replace("?", "%s")

            cursor.execute(adapted_sql, params)
            cols = [d[0] for d in cursor.description] if cursor.description else []
            return [dict(zip(cols, row)) for row in cursor.fetchall()]
    except Exception as e:
        logger.warning(f"[REPORTS] Query falhou: {e!r} | SQL: {sql[:100]}")
        return []


def _query_one(sql: str, params: tuple = ()) -> Optional[Dict]:
    rows = _query(sql, params)
    return rows[0] if rows else None


def _sqlite_date(days_back: int) -> str:
    """Retorna string de data ISO para comparação universal segura."""
    return (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d %H:%M:%S')


# ─── Data Collectors ────────────────────────────────────────────────

def collect_summary(days: int = 30) -> Dict[str, Any]:
    cutoff = _sqlite_date(days)
    row = None
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                row = _query_one("""
                    SELECT COUNT(*) as total,
                           SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed,
                           SUM(COALESCE(size_bytes,0)) as bytes,
                           0 as files,
                           AVG(CASE WHEN status='completed' THEN (julianday(end_time) - julianday(start_time)) * 86400 END) as avg_dur,
                           MAX(start_time) as last_exec
                    FROM backups
                    WHERE start_time >= ?
                """, (cutoff,))
            else:
                row = _query_one("""
                    SELECT COUNT(*) as total,
                           SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed,
                           SUM(COALESCE(bytes_processed,0)) as bytes,
                           SUM(COALESCE(files_processed,0)) as files,
                           AVG(CASE WHEN status='completed' THEN duration_seconds END) as avg_dur,
                           MAX(started_at) as last_exec
                    FROM task_executions
                    WHERE started_at >= ?
                """, (cutoff,))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_summary falhou: {err}")

    total = (row or {}).get('total', 0) or 0
    ok = (row or {}).get('ok', 0) or 0
    return {
        "period_days": days,
        "total_executions": total,
        "successful": ok,
        "failed": (row or {}).get('failed', 0) or 0,
        "success_rate": round(ok / total * 100, 1) if total else 0,
        "total_bytes": (row or {}).get('bytes', 0) or 0,
        "total_files": (row or {}).get('files', 0) or 0,
        "avg_duration_sec": round(float((row or {}).get('avg_dur', 0) or 0), 1),
        "last_execution": str((row or {}).get('last_exec', '') or ''),
    }


def collect_tasks_detail(days: int = 30) -> List[Dict]:
    cutoff = _sqlite_date(days)
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                return _query("""
                    SELECT t.id, t.name, t.engine,
                           COUNT(b.id) as total,
                           SUM(CASE WHEN b.status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(CASE WHEN b.status='failed' THEN 1 ELSE 0 END) as fail,
                           SUM(COALESCE(b.size_bytes,0)) as bytes,
                           AVG(CASE WHEN b.status='completed' THEN (julianday(b.end_time) - julianday(b.start_time)) * 86400 END) as avg_dur,
                           MAX(b.start_time) as last_run
                    FROM tasks t
                    LEFT JOIN backups b ON t.id=b.task_id AND b.start_time >= ?
                    GROUP BY t.id, t.name, t.engine
                    ORDER BY t.name
                """, (cutoff,))
            else:
                return _query("""
                    SELECT t.id, t.name, t.engine,
                           COUNT(te.id) as total,
                           SUM(CASE WHEN te.status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(CASE WHEN te.status='failed' THEN 1 ELSE 0 END) as fail,
                           SUM(COALESCE(te.bytes_processed,0)) as bytes,
                           AVG(CASE WHEN te.status='completed' THEN te.duration_seconds END) as avg_dur,
                           MAX(te.started_at) as last_run
                    FROM tasks t
                    LEFT JOIN task_executions te ON t.id=te.task_id AND te.started_at >= ?
                    GROUP BY t.id, t.name, t.engine
                    ORDER BY t.name
                """, (cutoff,))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_tasks_detail falhou: {err}")
        return []


def collect_daily_trend(days: int = 30) -> List[Dict]:
    cutoff = _sqlite_date(days)
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            date_col = "start_time" if tbl == 'backups' else "started_at"
            return _query(f"""
                SELECT DATE({date_col}) as day,
                       COUNT(*) as total,
                       SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as ok,
                       SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as fail
                FROM {tbl}
                WHERE {date_col} >= ?
                GROUP BY DATE({date_col})
                ORDER BY day
            """, (cutoff,))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_daily_trend falhou: {err}")
        return []


def collect_engine_comparison(days: int = 30) -> List[Dict]:
    cutoff = _sqlite_date(days)
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                return _query("""
                    SELECT t.engine,
                           COUNT(b.id) as total,
                           SUM(CASE WHEN b.status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(COALESCE(b.size_bytes,0)) as bytes,
                           AVG(CASE WHEN b.status='completed' THEN (julianday(b.end_time) - julianday(b.start_time)) * 86400 END) as avg_dur
                    FROM tasks t
                    LEFT JOIN backups b ON t.id=b.task_id AND b.start_time >= ?
                    GROUP BY t.engine
                    ORDER BY t.engine
                """, (cutoff,))
            else:
                return _query("""
                    SELECT t.engine,
                           COUNT(te.id) as total,
                           SUM(CASE WHEN te.status='completed' THEN 1 ELSE 0 END) as ok,
                           SUM(COALESCE(te.bytes_processed,0)) as bytes,
                           AVG(CASE WHEN te.status='completed' THEN te.duration_seconds END) as avg_dur
                    FROM tasks t
                    LEFT JOIN task_executions te ON t.id=te.task_id AND te.started_at >= ?
                    GROUP BY t.engine
                    ORDER BY t.engine
                """, (cutoff,))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_engine_comparison falhou: {err}")
        return []


def collect_errors(days: int = 30, limit: int = 20) -> List[Dict]:
    cutoff = _sqlite_date(days)
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                return _query("""
                    SELECT b.error_message, t.name as task_name, t.engine,
                           b.start_time as started_at, b.status
                    FROM backups b
                    JOIN tasks t ON b.task_id=t.id
                    WHERE b.status='failed' AND b.start_time >= ?
                    ORDER BY b.start_time DESC
                    LIMIT ?
                """, (cutoff, int(limit)))
            else:
                return _query("""
                    SELECT te.error_message, t.name as task_name, t.engine,
                           te.started_at, te.status
                    FROM task_executions te
                    JOIN tasks t ON te.task_id=t.id
                    WHERE te.status='failed' AND te.started_at >= ?
                    ORDER BY te.started_at DESC
                    LIMIT ?
                """, (cutoff, int(limit)))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_errors falhou: {err}")
        return []


def collect_sla(days: int = 30) -> List[Dict]:
    cutoff = _sqlite_date(days)
    rows = []
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                rows = _query("""
                    SELECT t.id, t.name, t.engine,
                           COUNT(b.id) as total_30d,
                           SUM(CASE WHEN b.status='completed' THEN 1 ELSE 0 END) as ok_30d,
                           MAX(CASE WHEN b.status='completed' THEN b.start_time END) as last_success,
                           MAX(CASE WHEN b.status='failed' THEN b.start_time END) as last_failure
                    FROM tasks t
                    LEFT JOIN backups b ON t.id=b.task_id AND b.start_time >= ?
                    GROUP BY t.id, t.name, t.engine
                """, (cutoff,))
            else:
                rows = _query("""
                    SELECT t.id, t.name, t.engine,
                           COUNT(te.id) as total_30d,
                           SUM(CASE WHEN te.status='completed' THEN 1 ELSE 0 END) as ok_30d,
                           MAX(CASE WHEN te.status='completed' THEN te.started_at END) as last_success,
                           MAX(CASE WHEN te.status='failed' THEN te.started_at END) as last_failure
                    FROM tasks t
                    LEFT JOIN task_executions te ON t.id=te.task_id AND te.started_at >= ?
                    GROUP BY t.id, t.name, t.engine
                """, (cutoff,))
    except Exception as err:
        logger.warning(f"[REPORTS] collect_sla falhou: {err}")

    for r in rows:
        total = r.get('total_30d', 0) or 0
        ok = r.get('ok_30d', 0) or 0
        r['success_rate'] = round(ok / total * 100, 1) if total else 0
        r['compliant'] = r['success_rate'] >= 95
    return rows


def collect_repos() -> List[Dict]:
    return _query("""
        SELECT r.id, r.name, r.engine, r.type, r.status,
               COUNT(t.id) as task_count
        FROM repositories r
        LEFT JOIN tasks t ON r.id=t.repository_id
        GROUP BY r.id, r.name, r.engine, r.type, r.status
        ORDER BY r.name
    """)


def collect_capacity() -> Dict[str, Any]:
    import psutil
    disk = psutil.disk_usage('C:' if __import__('platform').system() == 'Windows' else '/')
    return {
        "total_gb": round(disk.total / (1024 ** 3), 2),
        "used_gb": round(disk.used / (1024 ** 3), 2),
        "free_gb": round(disk.free / (1024 ** 3), 2),
        "usage_pct": round(disk.used / disk.total * 100, 1),
    }


# ─── HTML Report Builder ───────────────────────────────────────────

_CSS = """
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #0f1923;
    color: #e2e8f0;
    padding: 30px 20px;
}
.report {
    max-width: 1050px;
    margin: 0 auto;
    background: #182035;
    border: 1px solid #2a3f5f;
    border-radius: 12px;
    padding: 32px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.4);
}
.header {
    text-align: left;
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 2px solid #0284c7;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 16px;
}
.header h1 { font-size: 1.6em; color: #ffffff; font-weight: 800; margin-bottom: 4px; }
.header .subtitle { color: #94a3b8; font-size: 0.88em; }
.section { margin-bottom: 28px; }
.section h2 {
    font-size: 1.1em;
    color: #38bdf8;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 6px;
    border-bottom: 1px solid #334155;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 700;
}
.kpi-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.kpi {
    background: #111928;
    border: 1px solid #2a3f5f;
    border-radius: 8px;
    padding: 14px;
    text-align: center;
    border-left: 4px solid #0284c7;
}
.kpi .val { font-size: 1.5em; font-weight: 800; line-height: 1.2; }
.kpi .label { font-size: 0.72em; color: #94a3b8; text-transform: uppercase; font-weight: 700; margin-top: 4px; }
.kpi.green { border-left-color: #10b981; } .kpi.green .val { color: #10b981; }
.kpi.red { border-left-color: #ef4444; } .kpi.red .val { color: #ef4444; }
.kpi.blue { border-left-color: #0284c7; } .kpi.blue .val { color: #38bdf8; }
.kpi.orange { border-left-color: #f59e0b; } .kpi.orange .val { color: #f59e0b; }
.kpi.purple { border-left-color: #8b5cf6; } .kpi.purple .val { color: #a78bfa; }
table {
    width: 100%;
    border-collapse: collapse;
    background: #111928;
    border: 1px solid #2a3f5f;
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 20px;
    table-layout: auto;
}
th {
    background: #0d1526;
    color: #94a3b8;
    padding: 10px 12px;
    text-align: left;
    font-size: 0.75em;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    border-bottom: 1.5px solid #2a3f5f;
    white-space: nowrap;
}
td {
    padding: 9px 12px;
    border-top: 1px solid #2a3f5f;
    font-size: 0.84em;
    word-break: break-word;
}
tr:hover { background: rgba(56, 189, 248, 0.05); }
.badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 0.72em; font-weight: 700; }
.badge-ok { background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); }
.badge-fail { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3); }
.badge-warn { background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3); }
.bar-bg { height: 8px; background: #2a3f5f; border-radius: 4px; overflow: hidden; margin-top: 6px; }
.bar-fill { height: 100%; border-radius: 4px; transition: width .4s; }
.chart-placeholder { background: #111928; border: 1px solid #2a3f5f; border-radius: 8px; padding: 16px; margin-bottom: 16px; text-align: center; color: #94a3b8; }
.mini-chart { display: flex; align-items: flex-end; gap: 4px; height: 60px; justify-content: center; background: #111928; border-radius: 8px; padding: 12px; border: 1px solid #2a3f5f; margin-bottom: 16px; }
.mini-bar { width: 14px; border-radius: 3px 3px 0 0; min-height: 4px; }
.error-item { background: #111928; border: 1px solid #2a3f5f; border-radius: 6px; padding: 12px; margin-bottom: 8px; border-left: 4px solid #ef4444; }
.error-item .msg { font-size: 0.84em; color: #f8fafc; margin-bottom: 4px; }
.error-item .meta { font-size: 0.74em; color: #94a3b8; }
.footer { text-align: center; margin-top: 32px; padding-top: 16px; border-top: 1px solid #2a3f5f; color: #94a3b8; font-size: 0.75em; }

/* ─── PRINT / PDF STRICT A4 ANTI-OVERFLOW RULES ─── */
@page {
    size: A4 portrait;
    margin: 12mm 14mm 14mm 14mm;
}
@media print {
    *, *::before, *::after {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        box-shadow: none !important;
    }
    body { background: #ffffff !important; color: #0f172a !important; padding: 0 !important; font-size: 9pt !important; }
    .report { background: #ffffff !important; border: none !important; padding: 0 !important; max-width: 100% !important; border-radius: 0 !important; }
    .header { border-bottom: 2px solid #0284c7 !important; padding-bottom: 12px !important; margin-bottom: 14px !important; break-inside: avoid; page-break-inside: avoid; }
    .header h1 { color: #0f172a !important; font-size: 1.35em !important; }
    .header .subtitle { color: #64748b !important; }
    .section h2 { color: #0369a1 !important; border-bottom: 1px solid #cbd5e1 !important; }
    .kpi-row { grid-template-columns: repeat(4, 1fr) !important; gap: 8px !important; break-inside: avoid; page-break-inside: avoid; }
    .kpi { background: #f8fafc !important; border: 1px solid #cbd5e1 !important; border-left: 3px solid #0284c7 !important; padding: 8px !important; }
    .kpi .val { color: #0f172a !important; font-size: 1.25em !important; }
    .kpi .label { color: #64748b !important; }
    table { background: #ffffff !important; border: 1px solid #cbd5e1 !important; }
    thead { display: table-header-group !important; }
    tr { break-inside: avoid; page-break-inside: avoid; }
    th { background: #f1f5f9 !important; color: #0f172a !important; border-bottom: 1.5px solid #94a3b8 !important; padding: 6px 8px !important; font-size: 7.5pt !important; }
    td { border-top: 1px solid #e2e8f0 !important; color: #0f172a !important; padding: 6px 8px !important; font-size: 7.8pt !important; }
    .error-item { background: #fff5f5 !important; border-color: #fed7d7 !important; border-left-color: #ef4444 !important; break-inside: avoid; page-break-inside: avoid; }
    .error-item .msg { color: #991b1b !important; }
    .error-item .meta { color: #7f1d1d !important; }
    .footer { border-color: #cbd5e1 !important; color: #64748b !important; break-inside: avoid; page-break-inside: avoid; }
}
</style>
"""



def _fmt_bytes(b):
    if not b:
        return "0 B"
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if abs(b) < 1024:
            return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} PB"


def _fmt_dur(s):
    if not s:
        return "—"
    s = float(s)
    if s < 60:
        return f"{s:.0f}s"
    if s < 3600:
        return f"{s / 60:.0f}m {s % 60:.0f}s"
    return f"{s / 3600:.0f}h {(s % 3600) / 60:.0f}m"


def _fmt_date(d):
    if not d:
        return "—"
    if isinstance(d, str):
        return d[:19].replace('T', ' ')
    return d.strftime('%Y-%m-%d %H:%M:%S') if hasattr(d, 'strftime') else str(d)[:19]


def _rate_badge(rate):
    rate = float(rate or 0)
    cls = 'badge-ok' if rate >= 95 else 'badge-warn' if rate >= 80 else 'badge-fail'
    return f'<span class="badge {cls}">{rate:.1f}%</span>'


def _sla_badge(compliant):
    if compliant:
        return '<span class="badge badge-ok">Compliant</span>'
    return '<span class="badge badge-fail">Non-Compliant</span>'


def _bar_html(pct, color='#4299e1'):
    pct = min(100, max(0, float(pct or 0)))
    return f'<div class="bar-bg"><div class="bar-fill" style="width:{pct}%;background:{color}"></div></div>'


def _mini_chart_html(data_points: List[Dict], ok_key='ok', fail_key='fail', max_bars=30):
    if not data_points:
        return '<div class="chart-placeholder"><em>Sem dados para o período</em></div>'
    pts = data_points[-max_bars:]
    max_val = max(max((p.get(ok_key, 0) or 0) + (p.get(fail_key, 0) or 0) for p in pts), 1)
    bars = ''
    for p in pts:
        ok_h = int(((p.get(ok_key, 0) or 0) / max_val) * 50) + 4
        fail_h = int(((p.get(fail_key, 0) or 0) / max_val) * 50)
        bars += f'<div style="display:flex;flex-direction:column;gap:1px;align-items:center">'
        if fail_h > 0:
            bars += f'<div class="mini-bar" style="height:{fail_h}px;background:#f56565"></div>'
        bars += f'<div class="mini-bar" style="height:{ok_h}px;background:#48bb78"></div>'
        bars += '</div>'
    return f'<div class="mini-chart">{bars}</div>'


# ─── Report Types ──────────────────────────────────────────────────

def generate_executive_summary(days: int = 30) -> str:
    """Full executive summary report in HTML"""
    summary = collect_summary(days)
    tasks = collect_tasks_detail(days)
    trend = collect_daily_trend(days)
    engines = collect_engine_comparison(days)
    sla = collect_sla()
    repos = collect_repos()
    capacity = collect_capacity()
    errors = collect_errors(days, 10)
    now = datetime.now()

    compliant = sum(1 for s in sla if s.get('compliant'))
    sla_rate = round(compliant / len(sla) * 100, 1) if sla else 0

    html = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>GBOC Executive Report — {now.strftime('%d/%m/%Y')}</title>{_CSS}</head><body>
<div class="report">
<div class="header">
  <h1>📊 GBOC — Relatório Executivo de Backup</h1>
  <div class="subtitle">Período: últimos {days} dias • Gerado em: {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div>

<div class="section">
  <h2>📈 Resumo Geral</h2>
  <div class="kpi-row">
    <div class="kpi blue"><div class="val">{summary['total_executions']}</div><div class="label">Execuções</div></div>
    <div class="kpi green"><div class="val">{summary['successful']}</div><div class="label">Sucesso</div></div>
    <div class="kpi red"><div class="val">{summary['failed']}</div><div class="label">Falhas</div></div>
    <div class="kpi {'green' if summary['success_rate']>=95 else 'orange' if summary['success_rate']>=80 else 'red'}"><div class="val">{summary['success_rate']}%</div><div class="label">Taxa de Sucesso</div></div>
    <div class="kpi purple"><div class="val">{_fmt_bytes(summary['total_bytes'])}</div><div class="label">Dados Protegidos</div></div>
    <div class="kpi blue"><div class="val">{_fmt_dur(summary['avg_duration_sec'])}</div><div class="label">Duração Média</div></div>
  </div>
  {_mini_chart_html(trend)}
</div>

<div class="section">
  <h2>🎯 Compliance SLA</h2>
  <div class="kpi-row">
    <div class="kpi {'green' if sla_rate>=95 else 'orange' if sla_rate>=80 else 'red'}"><div class="val">{sla_rate}%</div><div class="label">SLA Compliance Geral</div></div>
    <div class="kpi green"><div class="val">{compliant}/{len(sla)}</div><div class="label">Tarefas Compliant</div></div>
  </div>
  <table><thead><tr><th>Tarefa</th><th>Engine</th><th>Exec. 30d</th><th>Taxa</th><th>SLA</th><th>Último Sucesso</th></tr></thead><tbody>"""

    for s in sla:
        html += f"""<tr><td>{s['name']}</td><td>{s['engine']}</td><td>{s.get('total_30d',0) or 0}</td>
        <td>{_rate_badge(s['success_rate'])}</td><td>{_sla_badge(s.get('compliant'))}</td>
        <td>{_fmt_date(s.get('last_success'))}</td></tr>"""

    html += """</tbody></table></div>

<div class="section">
  <h2>📋 Detalhamento por Tarefa</h2>
  <table><thead><tr><th>Tarefa</th><th>Engine</th><th>Execuções</th><th>Sucesso</th><th>Falhas</th><th>Taxa</th><th>Dados</th><th>Duração Média</th><th>Última Exec.</th></tr></thead><tbody>"""

    for t in tasks:
        total = t.get('total', 0) or 0
        ok = t.get('ok', 0) or 0
        rate = round(ok / total * 100, 1) if total else 0
        html += f"""<tr><td><strong>{t['name']}</strong></td><td>{t['engine']}</td>
        <td>{total}</td><td>{ok}</td><td>{t.get('fail',0) or 0}</td>
        <td>{_rate_badge(rate)}</td><td>{_fmt_bytes(t.get('bytes',0))}</td>
        <td>{_fmt_dur(t.get('avg_dur'))}</td><td>{_fmt_date(t.get('last_run'))}</td></tr>"""

    html += """</tbody></table></div>

<div class="section">
  <h2>⚙️ Comparação de Engines</h2>
  <table><thead><tr><th>Engine</th><th>Execuções</th><th>Sucesso</th><th>Taxa</th><th>Dados Totais</th><th>Duração Média</th></tr></thead><tbody>"""

    for e in engines:
        total = e.get('total', 0) or 0
        ok = e.get('ok', 0) or 0
        rate = round(ok / total * 100, 1) if total else 0
        html += f"""<tr><td><strong>{e['engine']}</strong></td><td>{total}</td><td>{ok}</td>
        <td>{_rate_badge(rate)}</td><td>{_fmt_bytes(e.get('bytes',0))}</td>
        <td>{_fmt_dur(e.get('avg_dur'))}</td></tr>"""

    html += """</tbody></table></div>

<div class="section">
  <h2>🗄️ Repositórios</h2>
  <table><thead><tr><th>Nome</th><th>Engine</th><th>Tipo</th><th>Status</th><th>Tarefas</th></tr></thead><tbody>"""

    for r in repos:
        st_cls = 'badge-ok' if r['status'] == 'active' else 'badge-fail'
        html += f"""<tr><td>{r['name']}</td><td>{r['engine']}</td><td>{r['type']}</td>
        <td><span class="badge {st_cls}">{r['status']}</span></td><td>{r.get('task_count',0)}</td></tr>"""

    html += f"""</tbody></table></div>

<div class="section">
  <h2>💾 Capacidade de Armazenamento</h2>
  <div class="kpi-row">
    <div class="kpi blue"><div class="val">{capacity['total_gb']} GB</div><div class="label">Total</div></div>
    <div class="kpi orange"><div class="val">{capacity['used_gb']} GB</div><div class="label">Usado</div></div>
    <div class="kpi green"><div class="val">{capacity['free_gb']} GB</div><div class="label">Livre</div></div>
    <div class="kpi {'green' if capacity['usage_pct']<80 else 'orange' if capacity['usage_pct']<90 else 'red'}"><div class="val">{capacity['usage_pct']}%</div><div class="label">Utilização</div></div>
  </div>
  {_bar_html(capacity['usage_pct'], '#4299e1' if capacity['usage_pct']<80 else '#ed8936' if capacity['usage_pct']<90 else '#f56565')}
</div>"""

    if errors:
        html += """<div class="section"><h2>❌ Erros Recentes</h2>"""
        for e in errors:
            msg = (e.get('error_message') or 'Sem mensagem')[:200]
            html += f"""<div class="error-item">
              <div class="msg">{msg}</div>
              <div class="meta">{e.get('task_name','')} • {e.get('engine','')} • {_fmt_date(e.get('started_at'))}</div>
            </div>"""
        html += "</div>"

    html += f"""
<div class="footer">
  GBOC Agent v{GBOC_VERSION} — Relatório gerado automaticamente em {now.strftime('%d/%m/%Y %H:%M:%S')}
</div>
</div></body></html>"""
    return html


def generate_sla_report(days: int = 30) -> str:
    """SLA compliance focused report"""
    sla = collect_sla()
    summary = collect_summary(days)
    now = datetime.now()
    compliant = sum(1 for s in sla if s.get('compliant'))
    sla_rate = round(compliant / len(sla) * 100, 1) if sla else 0

    html = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>GBOC SLA Report — {now.strftime('%d/%m/%Y')}</title>{_CSS}</head><body>
<div class="report">
<div class="header">
  <h1>🎯 GBOC — Relatório de Compliance SLA</h1>
  <div class="subtitle">Gerado em: {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div>
<div class="section">
  <div class="kpi-row">
    <div class="kpi {'green' if sla_rate>=95 else 'red'}"><div class="val">{sla_rate}%</div><div class="label">SLA Compliance</div></div>
    <div class="kpi blue"><div class="val">{len(sla)}</div><div class="label">Tarefas Monitoradas</div></div>
    <div class="kpi green"><div class="val">{compliant}</div><div class="label">Compliant</div></div>
    <div class="kpi red"><div class="val">{len(sla)-compliant}</div><div class="label">Non-Compliant</div></div>
  </div>
  <table><thead><tr><th>Tarefa</th><th>Engine</th><th>Execuções (30d)</th><th>Sucesso</th><th>Taxa</th><th>SLA</th><th>Último Sucesso</th><th>Última Falha</th></tr></thead><tbody>"""

    for s in sla:
        html += f"""<tr><td><strong>{s['name']}</strong></td><td>{s['engine']}</td>
        <td>{s.get('total_30d',0) or 0}</td><td>{s.get('ok_30d',0) or 0}</td>
        <td>{_rate_badge(s['success_rate'])}</td><td>{_sla_badge(s.get('compliant'))}</td>
        <td>{_fmt_date(s.get('last_success'))}</td><td>{_fmt_date(s.get('last_failure'))}</td></tr>"""

    html += f"""</tbody></table></div>
<div class="footer">GBOC Agent v{GBOC_VERSION} — Relatório SLA gerado em {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div></body></html>"""
    return html


def generate_capacity_report() -> str:
    """Storage capacity and forecast report"""
    capacity = collect_capacity()
    repos = collect_repos()
    trend = collect_daily_trend(90)
    now = datetime.now()

    # Simple growth estimation
    cutoff_30 = _sqlite_date(30)
    total_bytes_recent = 0
    try:
        core = _get_core()
        with core.get_db_connection() as conn:
            tbl = _detect_exec_table(conn)
            if tbl == 'backups':
                row_b = _query_one("SELECT SUM(size_bytes) as total FROM backups WHERE start_time >= ? AND status='completed'", (cutoff_30,))
                total_bytes_recent = (row_b or {}).get('total', 0) or 0
            else:
                row_b = _query_one("SELECT SUM(bytes_processed) as total FROM task_executions WHERE started_at >= ? AND status='completed'", (cutoff_30,))
                total_bytes_recent = (row_b or {}).get('total', 0) or 0
    except Exception as err:
        logger.warning(f"[REPORTS] Falha no cálculo de crescimento: {err}")
        total_bytes_recent = 0
    daily_growth_gb = round((total_bytes_recent or 0) / (1024**3) / 30, 2)
    days_until_full = int(capacity['free_gb'] / daily_growth_gb) if daily_growth_gb > 0 else None

    html = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>GBOC Capacity Report — {now.strftime('%d/%m/%Y')}</title>{_CSS}</head><body>
<div class="report">
<div class="header">
  <h1>💾 GBOC — Relatório de Capacidade</h1>
  <div class="subtitle">Gerado em: {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div>
<div class="section">
  <h2>📊 Visão Geral de Armazenamento</h2>
  <div class="kpi-row">
    <div class="kpi blue"><div class="val">{capacity['total_gb']} GB</div><div class="label">Capacidade Total</div></div>
    <div class="kpi orange"><div class="val">{capacity['used_gb']} GB</div><div class="label">Espaço Usado</div></div>
    <div class="kpi green"><div class="val">{capacity['free_gb']} GB</div><div class="label">Espaço Livre</div></div>
    <div class="kpi {'green' if capacity['usage_pct']<80 else 'red'}"><div class="val">{capacity['usage_pct']}%</div><div class="label">Utilização</div></div>
  </div>
  {_bar_html(capacity['usage_pct'], '#4299e1' if capacity['usage_pct']<80 else '#f56565')}
</div>
<div class="section">
  <h2>📈 Previsão de Crescimento</h2>
  <div class="kpi-row">
    <div class="kpi blue"><div class="val">{daily_growth_gb} GB/dia</div><div class="label">Crescimento Diário</div></div>
    <div class="kpi blue"><div class="val">{round(daily_growth_gb*30,1)} GB/mês</div><div class="label">Crescimento Mensal</div></div>
    <div class="kpi {'green' if not days_until_full or days_until_full>180 else 'orange' if days_until_full>60 else 'red'}"><div class="val">{days_until_full or '∞'} dias</div><div class="label">Dias até Cheio</div></div>
  </div>
</div>
<div class="section">
  <h2>🗄️ Repositórios</h2>
  <table><thead><tr><th>Nome</th><th>Engine</th><th>Tipo</th><th>Status</th><th>Tarefas</th></tr></thead><tbody>"""

    for r in repos:
        st = 'badge-ok' if r['status'] == 'active' else 'badge-fail'
        html += f"""<tr><td>{r['name']}</td><td>{r['engine']}</td><td>{r['type']}</td>
        <td><span class="badge {st}">{r['status']}</span></td><td>{r.get('task_count',0)}</td></tr>"""

    html += f"""</tbody></table></div>
<div class="footer">GBOC Agent v{GBOC_VERSION} — Relatório de Capacidade gerado em {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div></body></html>"""
    return html


def generate_error_report(days: int = 30) -> str:
    """Detailed error analysis report"""
    errors = collect_errors(days, 50)
    summary = collect_summary(days)
    now = datetime.now()

    # Group errors by task
    by_task = {}
    for e in errors:
        name = e.get('task_name', 'Unknown')
        by_task.setdefault(name, []).append(e)

    html = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>GBOC Error Report — {now.strftime('%d/%m/%Y')}</title>{_CSS}</head><body>
<div class="report">
<div class="header">
  <h1>❌ GBOC — Relatório de Erros</h1>
  <div class="subtitle">Últimos {days} dias • Gerado em: {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div>
<div class="section">
  <div class="kpi-row">
    <div class="kpi red"><div class="val">{summary['failed']}</div><div class="label">Total de Falhas</div></div>
    <div class="kpi blue"><div class="val">{summary['total_executions']}</div><div class="label">Total Execuções</div></div>
    <div class="kpi orange"><div class="val">{len(by_task)}</div><div class="label">Tarefas Afetadas</div></div>
  </div>
</div>"""

    for task_name, task_errors in by_task.items():
        html += f"""<div class="section"><h2>📋 {task_name} ({len(task_errors)} erros)</h2>"""
        for e in task_errors[:10]:
            msg = (e.get('error_message') or 'Sem mensagem')[:300]
            html += f"""<div class="error-item">
              <div class="msg">{msg}</div>
              <div class="meta">{e.get('engine','')} • {_fmt_date(e.get('started_at'))}</div>
            </div>"""
        html += "</div>"

    html += f"""<div class="footer">GBOC Agent v{GBOC_VERSION} — Relatório de Erros gerado em {now.strftime('%d/%m/%Y %H:%M:%S')}</div>
</div></body></html>"""
    return html


# Map of report types
REPORT_TYPES = {
    "executive": {"fn": generate_executive_summary, "label": "Relatório Executivo", "desc": "Resumo completo de backup, SLA, capacidade e erros"},
    "sla": {"fn": generate_sla_report, "label": "Relatório SLA", "desc": "Compliance de SLA por tarefa"},
    "capacity": {"fn": generate_capacity_report, "label": "Relatório de Capacidade", "desc": "Uso de armazenamento e previsão de crescimento"},
    "errors": {"fn": generate_error_report, "label": "Relatório de Erros", "desc": "Análise detalhada de falhas"},
}

