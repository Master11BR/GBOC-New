<!-- Copyright (c) 2026 Master11BR - GBOC System v14.8.1 Enterprise. Todos os direitos reservados. -->

# 🚀 GBOC - Gestão & Backup Operations Center (v14.8.1 Enterprise Edition)

[![GBOC System Version](https://img.shields.io/badge/version-14.8.1--Enterprise-blue.svg)](https://github.com/Master11BR/GBOC-New)
[![Python Version](https://img.shields.io/badge/python-3.11%2B%20%7C%203.14-green.svg)](https://www.python.org/)
[![PostgreSQL](https://img.shields.io/badge/postgresql-16-blue.svg)](https://www.postgresql.org/)
[![UI Model](https://img.shields.io/badge/UI__MODEL-modern%20(Official)-indigo.svg)]()
[![Status](https://img.shields.io/badge/status-production--ready-brightgreen.svg)]()

> **GBOC (Gestão & Backup Operations Center v14.8.1 Enterprise Edition)** é a mais avançada plataforma corporativa de orquestração de backup, Disaster Recovery (DR) 100% verificável ponta a ponta, RMM, telemetria real (Zero-Mock Strict), modelo visual universal **Modern UI (UnoCSS)**, **Padrão Oficial de Relatórios v3.0 & Flagships** e resposta cibernética a incidentes.

---

## 📌 Sumário
1. [Visão Geral e Arquitetura Operacional](#-visão-geral-e-arquitetura-operacional)
2. [Estrutura Canônica de Navegação (7 Domínios de Negócio)](#-estrutura-canônica-de-navegação)
3. [Recursos de Destaque (v14.8.1 Enterprise)](#-recursos-de-destaque-v1481-enterprise)
4. [Padrão Oficial de Relatórios v3.0 & Flagships](#-padrão-oficial-de-relatórios-v30--flagships)
5. [Disaster Recovery & SureRestore Sandbox Zero-Mock](#-disaster-recovery--surerestore-sandbox-zero-mock)
6. [Cyber Security Sentinel (ClamAV, YARA, Maltrail, Wazuh, Defender)](#-cyber-security-sentinel)
7. [Assistente de Inteligência Artificial & LLMs (Ollama & Nuvem)](#-assistente-de-inteligência-artificial--llms)
8. [Instalação & Configuração Rápida](#-instalação--configuração-rápida)

---

## 🏗️ Visão Geral e Arquitetura Operacional

O GBOC v14.8.1 opera sob o ciclo de vida completo e verificável de proteção contínua:

```text
Política → Backup consistente → Armazenamento → Integridade →
Teste de recuperação → Recuperação → Validação operacional → Evidência
```

```text
                  ┌────────────────────────────────────────┐
                  │             GBOC SERVER                │
                  │   - Dashboard Enterprise Canônico      │
                  │   - PostgreSQL 16 (Imunidade WAL)      │
                  │   - RMM Proxy & Espelho Web Agente     │
                  │   - SureRestore Sandbox & Multi-Tenant │
                  └───────────────────┬────────────────────┘
                                      │
                         HTTP/REST    │  WebSocket (Reboot Safe)
                         Porta 8000   │  Porta 9200 (Agente)
                                      ▼
               ┌──────────────────────────────────────────────┐
               │                 GBOC AGENT                   │
               │   - Direct-to-Cloud FastCDC Streaming        │
               │   - Cyber Security Sentinel (ClamAV/YARA)    │
               │   - AI Diagnostic Engine (Ollama/Cloud)      │
               │   - DR Backup S3 (.gbocdr 1-Click Restore)   │
               │   - Virtual Lab Sandbox (Switch Isolado)     │
               └──────┬────────────────┬───────────────┬──────┘
                      │                │               │
                      ▼                ▼               ▼
               ┌────────────┐   ┌────────────┐   ┌────────────┐
               │  FASTCDC   │   │ DUPLICATI  │   │   RESTIC   │
               │ (ENGINE 4) │   │ (NATIVO)   │   │  (CLI/API) │
               └────────────┘   └────────────┘   └────────────┘
```

---

## 🗺️ Estrutura Canônica de Navegação

A interface e as APIs do Servidor e Agente são organizadas estritamente em **7 Domínios Canônicos de Negócio**:

```text
Visão Geral
└── Dashboard Principal (/index.html / tab:overview)

Backup
├── Jobs e Políticas (/tasks.html / tab:backups)
├── Cargas Protegidas (/protected-workloads.html / tab:workloads — Bancos, AD, LTO, Oracle, SAP)
├── Repositórios (/repositories.html / tab:storage)
└── Restaurar e Validar (/restore.html / tab:surerestore — Assistente, Integridade, Sandbox)

Disaster Recovery
├── Prontidão e Plano (/disaster-recovery.html?tab=readiness / tab:dr-readiness)
├── Recuperação Instantânea (/disaster-recovery.html?tab=instant-vm / tab:instant-vm)
├── Bare Metal, P2V e Mídia (/disaster-recovery.html?tab=p2v / tab:p2v)
└── Laboratório e Validação (/disaster-recovery.html?tab=virtual-lab / tab:virtual-lab)

Proteção
├── Ransomware Guardian (/ransomware.html / tab:ransomware)
├── Conformidade (/compliance.html / tab:compliance)
└── Auditoria (/audit.html / tab:audit)

Virtualização e Cloud
├── VMware, Hyper-V e Proxmox (/virtualization.html / tab:virtualization)
├── Microsoft 365 e Exchange (/m365-exchange.html / tab:m365)
├── SaaS, Kubernetes e Cloud (/saas-cloud-enterprise.html / tab:saas-cloud)
└── Replicação (/replication.html / tab:replication)

Operações
├── Alertas e Falhas (/alerts.html / tab:alerts)
├── Logs Globais (/logs.html / tab:logs)
├── Diagnóstico (/diagnostic.html / tab:diagnostic)
└── Relatórios (/reports.html / tab:reports)

Configuração
├── Usuários e Permissões (/users.html / tab:users)
├── Notificações (/notification-channels.html / tab:notifications)
├── Armazenamento (/storage-usage.html / tab:storage)
├── Motores e Integrações (/engines.html / tab:engines)
└── Configurações Gerais (/settings.html / tab:config)
```

---

## ⚡ Recursos de Destaque (v14.8.1 Full Stable Enterprise)

- **Backup Imutável (S3 Object Lock & WORM Local)**:
  - **S3 Object Lock** nativo (S3/Wasabi/MinIO) por repositório com retenção configurável em dias e modos `GOVERNANCE` ou `COMPLIANCE`. Aplicação automática no bucket e auditoria periódica de bloqueio de objetos.
  - Uploads de motores de backup com validação obrigatória de cabeçalho `Content-MD5` (incluindo multipart).
  - **WORM Local para discos**: Bloqueio de arquivos como somente-leitura com ACLs do Windows de negação explícita de exclusão (`Deny Delete`), impedindo ransomware ou operadores de apagar repositórios dentro do período de retenção.
- **Implantação em Massa de Agentes (Tokens de Instalação)**:
  - Geração de tokens de instalação centralizados com vínculo por organização (tenant), prazo de expiração e contadores de uso.
  - Script autônomo `install_agent.ps1 -ServerURL -InstallToken -Unattended` pronto para distribuição em larga escala via GPO, script de logon ou ferramentas de RMM.
  - Agente registrado por token permanece travado na respectiva organização com resiliência de reconexão de até 72 horas.
- **Políticas Centrais de Backup com Detecção de Desvio (Drift Detection)**:
  - Gestão centralizada de regras de backup (agendamento, retenção, limites de banda, janelas de manutenção e políticas de imutabilidade) aplicadas em massa na frota de agentes.
  - Auditoria em tempo real de conformidade com sinalização semafórica de divergências e botão de reaplicação forçada.
- **Otimização e Resiliência da IA Local (Ollama)**:
  - Redução de mais de 85% no payload de prompts operacionais através de filtragem inteligente e truncamento adaptativo de históricos (`_smart_history_tokens`).
  - Resolução definitiva de erros de timeout em inferências pesadas de CPU com modelos 8B+ (Llama 3), com elevação do timeout padrão para 300s e capping seguro de `num_predict`.
  - Configuração do parâmetro de timeout diretamente na interface Web (`ai-timeout`) do Server e Agent.
  - Roteamento acelerado em milissegundos para comandos de ping, navegação e diagnósticos rápidos.
- **Operação Remota & Comercial MSP**:
  - **Portal do Cliente MSP (`/portal.html`)**: Painel isolado multi-tenant para visualização de faturas, relatórios executivos com a marca do cliente e saúde da proteção.
  - **Fechamento Mensal e Tarifação**: Cálculo automatizado por agente ativo, volume armazenado em TB e taxa fixa, com exportação CSV e hash criptográfico de integridade.
  - **Gerenciamento Remoto de Agentes**: Execução e parada de jobs, restauração remota de snapshots em diretório local do cliente e terminal remoto seguro.
  - **Catálogo de 20 Relatórios Reais**: Métricas calculadas sobre telemetria real (PostgreSQL/SQLite) com gráficos SVG vetoriais, exportação CSV/JSON e envio agendado por e-mail.
- **Recuperação de Corrupção Física de Dados & Alta Performance de Logs**:
  - Reparação autônoma de tabelas no PostgreSQL via rotinas tolerantes a corrupção e criação de índices compostos `idx_logs_timestamp_desc` (aceleração de 7.180x em consultas de log).
- **Arquitetura Operacional de DR & SureRestore Zero-Mock**:
  - Eliminação definitiva de declarações ou retornos simulados. Um ponto de restauração só recebe o status de *Aprovado* após boot real em VM isolada com validação de heartbeat e consistência de carga.
  - Estados padronizados: `Protegido`, `Em risco`, `Atenção`, `Falhou`, `Não protegido`.
  - Estados de validação: `Aprovado`, `Reprovado`, `Inconclusivo`, `Expirado`.
- **Restauração de Banco de Dados com Validação Estrita**:
  - PostgreSQL: Invocação de `pg_restore` em banco temporário com captura de `stderr` e falha explícita imediata se o código de saída for diferente de 0.
  - SQLite: Execução do `PRAGMA integrity_check;` e verificação da estrutura de tabelas.
- **Clonagem P2V & Streaming de Blocos**:
  - Criação de imagem VHDX com streaming direto de dados a partir de snapshot VSS consistente, validação de privilégios de Administrador e geração de manifesto de hardware VM (`.vmconfig.json`).
- **Backup de System State & Active Directory**:
  - Integração nativa com `wbadmin start systemstatebackup` e catálogo completo de consistência NTDS/SYSVOL, registro e manifesto criptográfico SHA-256 (`dr_manifest.json`).
- **Mídia de Boot WinPE / ISO Real**:
  - Extração automática de drivers de armazenamento, rede e RAID do host operacional via `Export-WindowsDriver`, scripts de recuperação autônoma e compilação de ISO bootável real via `oscdimg` (Windows ADK).
- **Virtual Lab Sandbox**:
  - Provisionamento e isolamento de rede em switch virtual privado (`GBOC-Isolated-Lab`), prevenindo qualquer colisão com o ambiente de produção.
- **Universal CSS & Cancelamento Real de Requisições**:
  - 100% de sincronização bidirecional de CSS e JS compartilhados (`gboc-perf.js`, `gboc-modal.js`, `gboc-layout-manager.js`, `gboc-hardware-hud.js`, `gboc-motion.js`).
  - Utilização de `gbocPerf.makeCancellable()` para abortar requisições pendentes em trocas de tela e buscas ativas.
  - Fallback resiliente no startup do servidor e agente para `httptools` e `uvloop`.

---

## 📊 Padrão Oficial de Relatórios v3.0 & Flagships

A partir da versão **14.7.0**, o sistema adota o padrão normativo v3.0 onde os 50 relatórios técnicos originais atuam com dados 100% reais alimentando **7 Relatórios Flagship de Mercado**, desenhados para narrativa executiva, clareza visual e conformidade com auditoria:

| Código | Relatório Flagship | Categoria | Público Principal | Destaque Visual |
|---|---|---|---|---|
| **`REP-F1`** | **Data Protection & Resilience Scorecard** | Executive Flagship | CISO, Diretor de TI, MSP | Score único 0–100, RPO/RTO por task |
| **`REP-F2`** | **Cyber Resilience & Ransomware Threat** | Security Flagship | CISO, SOC, Segurança | Linha do tempo de ameaças e canários |
| **`REP-F3`** | **Storage Intelligence Report** | Storage Flagship | Infraestrutura, FinOps | Projeção preditiva de esgotamento e FastCDC |
| **`REP-F4`** | **Compliance & Governance Report** | Governance Flagship | DPO, Auditoria, Compliance | Auditoria RPO/RTO em min, retenção e LGPD |
| **`REP-F5`** | **Operational Performance Report** | Operations Flagship | NOC, Engenharia, Backup Admin | Métricas individuais reais por job (sem médias) |
| **`REP-F6`** | **FinOps & Total Cost of Ownership** | FinOps Flagship | CFO, Gerente TI, MSP | Custo em USD/BRL (câmbio BCB em tempo real) |
| **`REP-F7`** | **Disaster Recovery Readiness** | DR Flagship | CTO, Gestão Continuidade | Matriz de prontidão para DR e gaps de RTO/RPO |

**Pilares Mandatórios da Arquitetura v3.0**:
- **Score Único Destacado**: Cada tela possui 1 número-síntese de 0 a 100 com semáforo de status.
- **Delta Comparativo**: Bloco automático de 3 bullets ("O que mudou") comparando com o ciclo anterior (`↑`, `↓`, `→`).
- **Narrativa antes da tabela**: Parecer e insights de IA inline contextuais prévios às tabelas de dados.
- **Métricas Individuais Reais**: Valores reais por ativo/tarefa, proibindo repetição de médias agregadas por linha.
- **Ações Priorizadas Obrigatórias**: Bloco formal de recomendações divididas por prioridade (`[ALTA]`, `[MÉDIA]`, `[BAIXA]`) com responsável sugerido e prazo.
- **4 Formatos Oficiais**: HTML Interativo, PDF/A4 Imprimível oficial com hash SHA-256 e assinatura digital, CSV Tabular e JSON REST API.

---

## 📜 Histórico de Mudanças (Changelog v14.8.1 Enterprise)

- **Release 14.8.1 — Backup Imutável, Implantação em Massa, Políticas Centrais, Otimização de IA Local & Comercial MSP (2026-10-05)**:
  - **Backup Imutável & S3 Object Lock**: Suporte nativo a Object Lock (Wasabi/S3/MinIO) com modos Governance/Compliance, auditoria periódica de bloqueio de objetos e validação de `Content-MD5`. WORM Local para armazenamento em disco com ACLs Windows de negação explícita de exclusão (`Deny Delete`).
  - **Implantação em Massa (Tokens de Instalação)**: Sistema de tokens gerados no Server com controle de tenant, expiração e quantidade de usos. Suporte a instalação 100% não assistida via `install_agent.ps1 -Unattended` para GPO e RMM.
  - **Políticas Centrais de Backup com Drift Detection**: Painel centralizado de governança permitindo aplicar parâmetros de backup, retenção, janela de manutenção e banda com detecção de desvio e botão de reaplicação forçada.
  - **Otimização e Resiliência da IA Local (Ollama)**: Redução de >85% na carga de tokens de prompts através de filtragem inteligente e truncamento adaptativo de históricos (`_smart_history_tokens`). Elevação do timeout padrão para 300s, capping seguro de tokens de saída em CPU e adição do parâmetro configurável `ai-timeout` nas telas de configurações do Server e Agent.
  - **Comercial MSP & Portal do Cliente**: Portal `/portal.html` dedicado a clientes finais, faturamento mensal consolidado com hash de integridade e exportação CSV, e licenciamento corporativo assinado via Ed25519.
  - **Sincronização de Distribuição e SemVer 14.8.1**: Atualização global de manifests, templates HTML, instaladores unificados e distribuição física em `GBOC-Distribution`.

- **Release 14.8.0 — Relatórios Reais, Painel de Decisão Executivo, Gerenciamento Remoto & SureRestore (2026-10-04)**:
  - **20 Relatórios Reais Substituindo Catálogo Estático**: Motor universal `report_core.py` operando com telemetria 100% real (PostgreSQL/SQLite), gráficos vetoriais SVG embutidos, integridade por hash SHA-256 e agendamento automático por e-mail.
  - **Painel de Decisão Executivo**: Visão holística da saúde do ambiente com KPIs de RPO, agentes online, falhas e recomendações priorizadas com deep link direto para o respectivo relatório.
  - **Gerenciamento Remoto de Agentes**: Execução de jobs, cancelamento, testes de restauração com validação de hash e terminal remoto WebSocket/HTTP direto.
  - **Alertas Proativos em Tempo Real**: Monitoramento preemptivo a cada 5 minutos com notificações adaptáveis para Microsoft Teams, Webhook e e-mail antes da ocorrência de falhas graves.

- **Release 14.7.6 — Recuperação de Integridade de Banco de Dados, Índices de Alta Performance & Modularização dos Logs do Sistema**:
  - **Reparação Física do PostgreSQL (`agent_logs`)**: Resolução de corrupção física de blocos de disco (`invalid page in block 73833`) na tabela de 4.542.898 registros via rotina automatizada de `VACUUM FULL VERBOSE` com tolerância controlada, salvaguardando a integridade transacional sem perda de dados históricos.
  - **Otimização de Índices (7.180x mais rápido)**: Implantação de índices dedicados `idx_logs_timestamp_desc` (`timestamp DESC`) e `idx_logs_level_time` (`level, timestamp DESC`), reduzindo o tempo de consulta de 2.829 ms para 0,39 ms com plano de execução otimizado `Index Scan`.
  - **Modularização de Logs & Filtros Semafóricos**: Criação do APIRouter modular `modules/logs/logs_router.py`, saneamento de rotas legadas duplicadas em `server_gboc.py`, inclusão do endpoint de sumário estatístico `/stats` e correção da função `mapLogToType()` no `dashboard.html`.
  - **Sincronização de Distribuição e SemVer 14.7.6**: Atualização de todos os manifestos de build, instaladores e pacotes externos em conformidade com as políticas de governança do GBOC.

- **Release 14.7.4 — Auditoria das Funções de IA, Zero-Mock Strict, Camada Multi-Provedores & Empacotamento de Distribuição**:
  - **Camada Unificada de Provedores de IA**: Módulo `ai_providers.py` idêntico e compartilhado entre Server e Agent suportando 10 provedores de ponta com isolamento estrito de parâmetros e chaves.
  - **Blindagem Zero-Mock Estrita**: Telemetria real em `/diagnose` via `psutil`, consulta ao PostgreSQL e SQLite nos Copilots, eliminação de frases fabricadas e reescrita do REP-F6 AI Predictive Suite com regressão linear real.
  - **Segurança de Endpoints e OWASP**: Autenticação obrigatória em rotas de IA, sanitização XSS, mascaramento de credenciais e middleware *fail-closed*.
  - **Empacotamento e Instalador 14.7.4**: Atualização de `Setup.bat`, `Setup.ps1`, `make_distribution.py`, `package_manifest.json` e documentação formal ISO/IEC.

- **Release 14.7.3 — AI Copilot Router Modernization, Security Auth Enforcement & Predictive Fallback Precision**:
  - **Função Standalone Multi-Provedor (`query_server_ai_assistant`)**: Desacoplamento da inferência de IA (DeepSeek, Ollama, Groq, OpenAI, Gemini, Claude) em função reutilizável retornando `dict`, restabelecendo a operação da rota oficial `/api/v2/ai/query` (eliminação definitiva do erro `ImportError`).
  - **Imposição de Autenticação Segura em 7 Endpoints de IA**: Blindagem contra explorações não autenticadas e SSRF em `/query`, `/config` (GET/POST), `/diagnose`, `/auto_fix`, `/ollama/models` (GET/POST) e `/ollama/models/pull`, exigindo token de sessão válido (`Bearer` ou cookie `gboc_server_token`).
  - **Precisão Semântica do Fallback Preditivo**: Retorno de tupla com telemetria de falhas em `_build_server_system_context()`, reportando `🔴 {N} job(s) com falha registrado(s)` quando incidentes reais são detectados e `🟢 Nenhum erro` apenas sob conformidade estrita comprovada.

- **Release 14.7.2 — Logs Sentinel UI, Kyle Zantos Motion Principles & Core Engine Runtime Fixes**:
  - Resolução de 10 exceções de runtime `NameError` identificadas por auditoria estática (pyflakes): inicialização de logger em `diagnostic_report.py` e `flagship_reports.py`, importação de `db_manager` e saneamento de 9 referências quebradas em `reports_router.py`, importação de `Request` e `time` em `diagnostics.py`, timezone em `auth.py`, `Path` em `shared_core.py`, `time` em `healer_engine.py`, `shutil` em `engine_validator.py`, `psycopg2` em `backup_engine_manager.py` e `time` em `reports_api.py`.
  - Nova interface Premium Toast Notification para Logs do Sistema (`logs.html` e `modules/logs/logs.html`), aplicando Kyle Zantos Motion Principles (animações suaves `@keyframes appear` e `@keyframes disappear`), isolamento por grid horizontal estruturado em 3 colunas, pseudo-elementos flutuantes `::before`/`::after` com efeito de bolhas translúcidas e ícones frosted glass.
  - Filtros cromáticos semafóricos por severidade real (`Success`, `Info`, `Warning`, `Error`) com gradientes táteis vivos, busca em tempo real e mapeamento analítico de eventos no banco de dados.
  - Paridade Universal CSS (Universal CSS Architecture Policy) sincronizada entre `shared-css`, `GBOC-Agent` e `GBOC-Server`.

- **Release 14.7.0 — Padrão Oficial de Relatórios v3.0 & Zero-Mock Intelligence**:
  - Implementação de `v3_reports_engine.py` eliminando dados fictícios em todos os 50 relatórios.
  - Correção dos 10 bugs de dados: RPO por task, throughput real por engine, retenção de settings, DLQ auditada, uptime via psutil, testes reais de restauração, shield de canários reais, predição por regressão linear e parecer analítico cruzado de IA.
  - Status transparente `status: "unavailable"` para relatórios sem sensor local.
  - Higienização de nomes técnicos via `_clean_task_name()`.
  - Atualização do visualizador `reports.html` com badges semafóricos, dots, metas e ações recomendadas.
  - Sincronização simétrica dos 7 Flagships no Server e Agent com `schema_version: "3.0.0"`.

- **Release 14.6.1 — Arquitetura de Relatórios Flagship v2.0**:
  - Consolidação dos 7 Relatórios Flagship executivos.

- **Release 14.6.0 — Operational Backup & DR**:
  - Reestruturação Canônica de Navegação (7 Domínios de Negócio).
  - Eliminação de Simulações & Zero-Mock Strict Policy em SureRestore.

- **Reestruturação Canônica de Navegação (7 Domínios de Negócio)**:
  - Alinhamento completo da Sidebar e Topbar no Server e no Agent com os domínios: *Visão Geral, Backup, Disaster Recovery, Proteção, Virtualização & Cloud, Operações e Configuração*.
  - Criação do módulo consolidado de **Cargas Protegidas** ([`protected-workloads.html`](file:///d:/GBOC-New/GBOC-New/GBOC-Agent/static/protected-workloads.html) e [`protected-workloads.js`](file:///d:/GBOC-New/GBOC-New/GBOC-Agent/static/protected-workloads.js)).
  - Adição de sub-abas consolidadas em `restore.html`, `alerts.html`, `diagnostic.html`, `engines.html` e `disaster-recovery.html`.
  - Mapeamento de aliases e suporte a deep linking via URL params com preservação de retrocompatibilidade de URLs legadas.
- **Eliminação de Simulações & Zero-Mock Strict Policy**:
  - SureRestore Sandbox reescrito para validação real no hypervisor (`surerestore_router.py`).
  - Falha explícita garantida em `_test_restore_pg()` para retornos com código != 0 e SQLite integrity check.
  - P2V atualizado com leitura real de blocos, checagem de privilégios de Administrador e geração de descritor de VM.
  - Backup de System State e AD com suporte a `wbadmin` e manifesto SHA-256.
  - Staging de Mídia de Boot WinPE com exportação real de drivers via PowerShell e compilação de ISO.
  - Virtual Lab Sandbox com ciclo de vida completo de VM isolada e verificação de heartbeat WMI.
- **Estabilidade do Frontend & Pipeline de Build**:
  - Correção da classe inacabada no [`task_monitor.js`](file:///d:/GBOC-New/GBOC-New/GBOC-Agent/static/task_monitor.js).
  - Correção da função `safeRender` em [`gboc-perf.js`](file:///d:/GBOC-New/GBOC-New/shared-css/gboc-perf.js) com comparação completa `_gbocLastHtml`.
  - Inclusão de `gboc-perf.js` e scripts compartilhados na fonte canônica `shared-css/` e no sincronizador `sync_css.py`.
  - Execução obrigatória do gatekeeper `python tools/sync_css.py --verify` antes da geração do pacote de distribuição no `make_distribution.py`.
  - Implementação de fallback dinâmico para `httptools` e `uvloop` em `agent_gboc.py`, `agent_server.py`, `server_gboc.py` e `gboc_server.py`.
  - Aplicação de `gbocPerf.makeCancellable()` nas telas de alta frequência.
  - Incremento global de versão para **v14.6.0 Full Stable Enterprise**.

---

## 🛡️ Cyber Security Sentinel

Integrado com os 5 principais ecossistemas globais de segurança:

1. **Windows Defender Native Hook**: Leitura via WMI PowerShell (`Get-MpComputerStatus`) e disparo automático de varreduras (`Start-MpScan`).
2. **ClamAV Antivirus**: Varredura por assinatura de código malicioso antes e depois da execução de backups.
3. **YARA Rules Engine**: Regras heurísticas para identificação de ransomwares e notas de resgate.
4. **Maltrail Threat Feed**: Checagem de reputação de IPs e domínios C2 (Command & Control).
5. **Wazuh HIDS / SIEM**: Encaminhamento de logs de auditoria de segurança padronizados em JSON.

---

## 🤖 Assistente de Inteligência Artificial & LLMs

- **Multi-Provedor**: Integração real com Ollama Local (`http://localhost:11434`), OpenAI, Gemini e DeepSeek.
- **Assistência Integrada em Todos os Módulos**: Diagnósticos preditivos com botão de **"Solução em 1-Clique"** nas telas de Diagnóstico, Logs, Tarefas, Compliance e Alertas.

---

## ⚙️ Instalação & Configuração Rápida

### Pré-requisitos
- **Windows Server 2016+ / Windows 10/11** ou **Linux Ubuntu 22.04+ / Debian 12+**
- **Python 3.11+ / 3.14**
- **PostgreSQL 14+ / 16** (para o Servidor Central)

### Iniciar Servidor Central
```powershell
cd GBOC-Server
python server_gboc.py
```
Acesse: `http://localhost:8000`

### Iniciar Agente Local
```powershell
cd GBOC-Agent
python agent_gboc.py
```
Acesse: `http://localhost:9200`
