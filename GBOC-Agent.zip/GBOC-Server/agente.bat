@REM ==============================================================================
@REM GBOC System v14.1.0 Enterprise Edition
@REM Copyright (c) 2026 Master11BR - Todos os direitos reservados.
@REM Propriedade Intelectual & Direitos Autorais Registrados.
@REM ==============================================================================

@echo off
uvicorn main:app --reload --port 8000 --host 0.0.0.0