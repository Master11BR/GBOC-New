# ==============================================================================
# GBOC System v14.8.1 Enterprise Edition
# Copyright (c) 2026 Master11BR - Todos os direitos reservados.
# Propriedade Intelectual & Direitos Autorais Registrados.
# ==============================================================================

"""
make_distribution.py
Script de empacotamento para gerar o pacote de instalação do GBOC System.
Copia de forma limpa os componentes Server, Agent, manifestos e instalador
para uma pasta de distribuição externa.
"""

import sys
import shutil
import json
import argparse
from pathlib import Path

# Diretórios e arquivos a ignorar durante a cópia
IGNORE_PATTERNS = shutil.ignore_patterns(
    "__pycache__",
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".pytest_cache",
    ".git",
    ".github",
    ".vs",
    ".vscode",
    "*.log",
    "logs",
    "startup_*.log",
    "*.tmp",
    "*.swp",
    # nunca distribuir chave privada de licença (fica só com o fornecedor)
    "*license_private*.pem",
    "*_private_key.pem",
    # chave local que criptografa as credenciais de nuvem dos repositórios (cada agente gera a sua)
    ".repo_secrets.key",
    # estado de execução da máquina de desenvolvimento: bancos locais das tarefas
    # Duplicati (listas de arquivos dos backups), fila do Hermes e journals SQLite
    "duplicati_dbs",
    "hermes_queue.db*",
    "*.sqlite-shm",
    "*.sqlite-wal",
    "*.db-shm",
    "*.db-wal"
)

def create_unified_requirements(server_req_path: Path, agent_req_path: Path, output_path: Path):
    """Combina dependências únicas do Server e Agent em um arquivo consolidado."""
    dependencies = set()
    
    for req_file in [server_req_path, agent_req_path]:
        if req_file.exists():
            with open(req_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        dependencies.add(line)
                        
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# GBOC System v14.8.2 - Dependencias Consolidadas (Server + Agent)\n")
        for dep in sorted(dependencies):
            f.write(f"{dep}\n")
    print(f"  [OK] Dependencias consolidadas criadas em: {output_path}")

# Dados de USO desta maquina que nao podem ir no pacote (bancos, chaves TLS, identidade do agente e chave do
# Servidor central em data/central, configuracoes com senhas, repositorios de backup...). Relativo a raiz do componente.
RUNTIME_PATHS = {
    "GBOC-Agent": ["data", "repositorios", "enc-v1", "config/global_settings.json"],
    "GBOC-Server": ["data"],
}


def prune_runtime(target_dir: Path, component_name: str):
    """Remove do pacote os dados de uso copiados junto com o codigo e recria as pastas vazias."""
    removed = []
    for rel in RUNTIME_PATHS.get(component_name, []):
        p = target_dir / rel
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
            removed.append(rel + "/")
        elif p.exists():
            p.unlink()
            removed.append(rel)
    for rel in RUNTIME_PATHS.get(component_name, []):
        if "." not in Path(rel).name and rel != "enc-v1":
            (target_dir / rel).mkdir(parents=True, exist_ok=True)      # pastas vazias (o sistema preenche no uso)
    if removed:
        print(f"  [OK] {component_name}: dados de uso desta maquina fora do pacote: {', '.join(removed)}")


def copy_component(source_dir: Path, target_dir: Path, component_name: str):
    """Copia uma árvore de diretórios aplicando filtro de exclusão."""
    if not source_dir.exists():
        print(f"  [ERRO] Diretorio de origem nao encontrado: {source_dir}")
        return False
        
    print(f"  -> Copiando {component_name} de {source_dir} para {target_dir}...")
    if target_dir.exists():
        shutil.rmtree(target_dir)
        
    shutil.copytree(source_dir, target_dir, ignore=IGNORE_PATTERNS)
    print(f"  [OK] {component_name} copiado com sucesso!")
    return True

def get_current_version(source_root: Path) -> str:
    vc_path = source_root / "GBOC-Agent" / "version_control.py"
    if vc_path.exists():
        try:
            agent_dir = str(source_root / "GBOC-Agent")
            if agent_dir not in sys.path:
                sys.path.insert(0, agent_dir)
            import version_control
            return f"v{version_control.__version__} Full Stable Enterprise"
        except Exception:
            pass
    return "v14.8.2 Full Stable Enterprise"

def generate_manifest(output_dir: Path, version: str = "v14.8.2 Full Stable Enterprise"):
    """Gera um arquivo de manifesto com metadados do pacote gerado."""
    manifest = {
        "system": "GBOC System",
        "version": version,
        "release_date": "2026",
        "author": "Master11BR",
        "components": {
            "GBOC-Server": {
                "installed": (output_dir / "Server").exists(),
                "default_port": 8000
            },
            "GBOC-Agent": {
                "installed": (output_dir / "Agent").exists(),
                "default_port": 9200
            }
        },
        "installer_version": "2.0.0"
    }
    
    manifest_path = output_dir / "package_manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=4, ensure_ascii=False)
    print(f"  [OK] Manifesto de versao gerado em: {manifest_path}")

def build_package(source_root: Path, output_dir: Path, clean: bool = False):
    """Executa a criacao do pacote de distribuicao."""
    current_version = get_current_version(source_root)
    print("=" * 70)
    print(f"  GBOC System ({current_version}) - Gerador de Pacote & Instalador")
    print("=" * 70)
    print(f"Origem do Codigo: {source_root}")
    print(f"Destino do Pacote: {output_dir}\n")

    if clean and output_dir.exists():
        print(f"Limpando diretorio de saida existente: {output_dir}")
        try:
            shutil.rmtree(output_dir, ignore_errors=True)
        except Exception:
            pass

    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 0. Sincronizar e verificar CSS/JS canonicos antes de empacotar
    sync_script = source_root / "tools" / "sync_css.py"
    if sync_script.exists():
        print("  -> Sincronizando e verificando CSS e JS canonicos compartilhados...")
        import subprocess
        res_sync = subprocess.run([sys.executable, str(sync_script)], capture_output=True, text=True)
        if res_sync.returncode != 0:
            print(f"[ERRO] Falha ao sincronizar CSS/JS canonicos:\n{res_sync.stderr or res_sync.stdout}")
            sys.exit(1)
        res_verify = subprocess.run([sys.executable, str(sync_script), "--verify"], capture_output=True, text=True)
        if res_verify.returncode != 0:
            print(f"[ERRO] Divergencia nos arquivos canonicos durante verificacao:\n{res_verify.stderr or res_verify.stdout}")
            sys.exit(1)
        print("  [OK] CSS e JS compartilhados 100% sincronizados e verificados.")

    # 1. Copiar GBOC-Server
    server_src = source_root / "GBOC-Server"
    server_dst = output_dir / "Server"
    copy_component(server_src, server_dst, "GBOC-Server")
    prune_runtime(server_dst, "GBOC-Server")

    # 2. Copiar GBOC-Agent
    agent_src = source_root / "GBOC-Agent"
    agent_dst = output_dir / "Agent"
    copy_component(agent_src, agent_dst, "GBOC-Agent")
    prune_runtime(agent_dst, "GBOC-Agent")

    # 3. Criar pasta Dependencies
    deps_dir = output_dir / "Dependencies"
    deps_dir.mkdir(exist_ok=True)
    
    # Copiar requirements individuais
    if (server_src / "requirements.txt").exists():
        shutil.copy2(server_src / "requirements.txt", deps_dir / "requirements-server.txt")
    if (agent_src / "requirements.txt").exists():
        shutil.copy2(agent_src / "requirements.txt", deps_dir / "requirements-agent.txt")
    if (agent_src / "requirements-optional.txt").exists():
        shutil.copy2(agent_src / "requirements-optional.txt", deps_dir / "requirements-optional.txt")
        
    # Gerar requirements unificado
    create_unified_requirements(
        server_src / "requirements.txt",
        agent_src / "requirements.txt",
        deps_dir / "requirements-all.txt"
    )

    # 4. Gerar manifesto
    generate_manifest(output_dir, version=current_version)

    # 5. Gerar LEIAME_INSTALACAO.md
    readme_content = f"""# GBOC System {current_version} — Pacote de Instalacao

Este pacote contem todos os arquivos e dependencias para instalar o GBOC Server, o GBOC Agent ou Ambos.

## Como Instalar:
1. Clique duas vezes em Setup.bat (Executar como Administrador).
2. Escolha no menu:
   - [1] GBOC Agent (Agente de backup local, porta 9200)
   - [2] GBOC Server (Painel central e API, porta 8000)
   - [3] GBOC Enterprise Completo (Servidor e Agente juntos no mesmo host)
   - [4] Apenas Dependencias e Motores (Restic, Kopia, pacotes Python)

3. O instalador configura automaticamente:
   - Ambiente virtual Python isolado (venv)
   - Todas as bibliotecas Python necessarias
   - Motores de backup Restic e Kopia
   - Scripts de inicializacao rapida (start_all.bat, stop_all.bat, uninstall.bat)
   - Atalhos na Area de Trabalho

## Instalacao Silenciosa via Linha de Comando (PowerShell):
```powershell
powershell -ExecutionPolicy Bypass -File .\\Setup.ps1 -InstallMode Agent -TargetDir "C:\\GBOC"
powershell -ExecutionPolicy Bypass -File .\\Setup.ps1 -InstallMode Server -TargetDir "C:\\GBOC"
powershell -ExecutionPolicy Bypass -File .\\Setup.ps1 -InstallMode Both -TargetDir "C:\\GBOC"
```
"""
    with open(output_dir / "LEIAME_INSTALACAO.md", "w", encoding="utf-8") as f:
        f.write(readme_content)
    print(f"  [OK] Guia LEIAME_INSTALACAO.md gerado em: {output_dir / 'LEIAME_INSTALACAO.md'}")

    print("\n" + "=" * 70)
    print("  [OK] Pacote de distribuicao gerado com sucesso!")
    print(f"  Localizacao: {output_dir}")
    print("=" * 70)

def main():
    parser = argparse.ArgumentParser(description="Gerador de Pacote de Distribuicao GBOC")
    parser.add_argument("--source", type=str, default=str(Path(__file__).resolve().parent.parent),
                        help="Diretorio raiz do projeto GBOC")
    parser.add_argument("--output", type=str, required=True,
                        help="Diretorio de destino do pacote (fora dos fontes atuais)")
    parser.add_argument("--clean", action="store_true",
                        help="Limpar diretorio de destino antes de copiar")
    
    args = parser.parse_args()
    source_path = Path(args.source).resolve()
    output_path = Path(args.output).resolve()

    build_package(source_path, output_path, clean=args.clean)

if __name__ == "__main__":
    main()
