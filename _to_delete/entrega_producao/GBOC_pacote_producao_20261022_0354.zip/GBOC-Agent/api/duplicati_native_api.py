#!/usr/bin/env python3
"""
API do módulo isolado de integração com Duplicati.
"""

from typing import Any, Dict

from fastapi import APIRouter, HTTPException, Request

from core.integrations.duplicati_native import get_duplicati_native_service

router = APIRouter(prefix="/api/duplicati-native", tags=["duplicati-native"])


def _require_admin(request: Request) -> Dict[str, Any]:
    """Sessão válida + perfil administrador (mesmo critério das demais rotas sensíveis do Agente)."""
    from api.auth import get_current_user, is_auth_enabled
    from api.ai_api import ADMIN_ROLES, _get_user_role

    if not is_auth_enabled():
        raise HTTPException(status_code=401, detail="Configuração inicial de autenticação necessária.")
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Autenticação necessária.")
    if (_get_user_role(user.get("user_id")) or "").lower() not in ADMIN_ROLES:
        raise HTTPException(status_code=403, detail="Permissão negada: somente administradores podem ver a senha gerenciada.")
    return user


@router.get("/managed-password")
async def get_managed_password(request: Request) -> Dict[str, Any]:
    """Senha do Duplicati definida pelo próprio GBOC (só administradores; cada consulta fica auditada)."""
    user = _require_admin(request)
    service = get_duplicati_native_service()
    cfg = service.load_config()
    extra = service._load_extra()
    if not extra.get("password_managed") or not cfg.password:
        raise HTTPException(status_code=404, detail="Não há senha gerenciada pelo GBOC (a senha foi informada manualmente).")
    try:
        from api.audit_api import audit_security_event
        audit_security_event("duplicati_managed_password_viewed", username=user.get("username"),
                             ip=(request.client.host if request.client else None),
                             detail={"password_set_at": extra.get("password_set_at", "")})
    except Exception:
        pass
    return {"status": "success", "password": cfg.password,
            "password_set_at": extra.get("password_set_at", ""),
            "base_url": cfg.base_url, "username": cfg.username}


@router.get("/status")
async def get_status() -> Dict[str, Any]:
    service = get_duplicati_native_service()
    return {
        "config": service.get_config_summary(),
        "probe": service.probe(),
    }


@router.get("/config")
async def get_config() -> Dict[str, Any]:
    service = get_duplicati_native_service()
    return service.get_config_summary()


@router.post("/config")
async def save_config(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        service = get_duplicati_native_service()
        cfg = service.save_config(payload)
        return {
            "status": "success",
            "message": "Configuração do Duplicati salva",
            "config": {
                "base_url": cfg.base_url,
                "username": cfg.username,
                "password_masked": service.get_config_summary().get("password_masked", ""),
                "verify_tls": cfg.verify_tls,
                "timeout_seconds": cfg.timeout_seconds,
            },
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/discover")
async def discover() -> Dict[str, Any]:
    service = get_duplicati_native_service()
    return {"endpoints": service.discover_endpoints()}


@router.get("/backups")
async def list_backups() -> Dict[str, Any]:
    service = get_duplicati_native_service()
    result = service.list_backups()
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups")
async def create_backup(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Cria uma nova rotina de backup no Duplicati nativo e vincula ao GBOC."""
    try:
        service = get_duplicati_native_service()
        result = service.create_backup(payload)
        if result.get("status") == "error":
            err_msg = result.get("message") or result.get("error") or "Falha ao criar backup no Duplicati"
            raise HTTPException(status_code=400, detail=str(err_msg))
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@router.post("/sync")
@router.get("/sync")
async def sync_duplicati() -> Dict[str, Any]:
    """Sincroniza os backups e execuções do Duplicati Native com o banco de dados do GBOC."""
    try:
        service = get_duplicati_native_service()
        result = service.sync_to_gboc()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/backups/{backup_id}/filesets")
async def list_backup_filesets(backup_id: str) -> Dict[str, Any]:
    """Lista snapshots / pontos de recuperação de um backup do Duplicati."""
    service = get_duplicati_native_service()
    snapshots = service.list_filesets(backup_id)
    return {
        "status": "success",
        "backup_id": backup_id,
        "count": len(snapshots),
        "snapshots": snapshots
    }


# ── Controle de Jobs ──────────────────────────────────────────────────────────

@router.get("/progress")
async def get_progress() -> Dict[str, Any]:
    """Estado de progresso atual do Duplicati."""
    service = get_duplicati_native_service()
    result = service.get_progress()
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.get("/serverstate")
async def get_server_state() -> Dict[str, Any]:
    """Estado do servidor Duplicati (scheduled, running, paused...)."""
    service = get_duplicati_native_service()
    result = service.get_server_state()
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups/{backup_id}/run")
async def run_backup(backup_id: str) -> Dict[str, Any]:
    """Inicia um job de backup manualmente."""
    service = get_duplicati_native_service()
    result = service.run_backup(backup_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups/{backup_id}/stop")
async def stop_backup(backup_id: str, abort: bool = False) -> Dict[str, Any]:
    """Para ou aborta um job de backup em execução. Use abort=true para forçar."""
    service = get_duplicati_native_service()
    result = service.stop_backup(backup_id, abort=abort)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.get("/backups/{backup_id}/log")
async def get_backup_log(backup_id: str, page_size: int = 20) -> Dict[str, Any]:
    """Log de execuções de um job específico."""
    service = get_duplicati_native_service()
    result = service.get_backup_log(backup_id, page_size=page_size)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/server/pause")
async def pause_server() -> Dict[str, Any]:
    """Pausa o agendador do Duplicati."""
    service = get_duplicati_native_service()
    result = service.pause_server()
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/server/resume")
async def resume_server() -> Dict[str, Any]:
    """Retoma o agendador do Duplicati."""
    service = get_duplicati_native_service()
    result = service.resume_server()
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


# ── Agendamento ───────────────────────────────────────────────────────────────

@router.post("/backups/{backup_id}/schedule")
async def set_schedule(backup_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Define ou atualiza o agendamento automático de um job de backup.

    Corpo esperado:
    ```json
    {
      "time": "02:00",
      "repeat": "1D",
      "allowed_days": ["mon","tue","wed","thu","fri"],
      "tags": []
    }
    ```
    """
    service = get_duplicati_native_service()
    result = service.set_schedule(backup_id, payload)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


# ── Restauração ───────────────────────────────────────────────────────────────

@router.post("/backups/{backup_id}/restore")
async def restore_backup(backup_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Inicia a restauração de arquivos de um backup.

    Corpo esperado:
    ```json
    {
      "restore_path": "C:\\RestoreDir",
      "paths": [],
      "overwrite": false,
      "time": "now",
      "passphrase": ""
    }
    ```
    """
    service = get_duplicati_native_service()
    result = service.restore_backup(backup_id, payload)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


# ── Resultado da última execução ──────────────────────────────────────────────

@router.get("/backups/{backup_id}/lastresult")
async def get_last_result(backup_id: str) -> Dict[str, Any]:
    """Retorna o ParsedResult e erros da última execução do backup."""
    service = get_duplicati_native_service()
    result = service.get_last_result(backup_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


# ── Criação, Exclusão, Reparo e Manutenção de Backups ──────────────────────────

@router.delete("/backups/{backup_id}")
async def delete_backup(backup_id: str, delete_remote_files: bool = False) -> Dict[str, Any]:
    """Exclui um job de backup do Duplicati."""
    service = get_duplicati_native_service()
    result = service.delete_backup(backup_id, delete_remote_files=delete_remote_files)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups/{backup_id}/repair")
async def repair_backup(backup_id: str) -> Dict[str, Any]:
    """Executa a reconstrução/reparo do banco local do backup."""
    service = get_duplicati_native_service()
    result = service.repair_backup(backup_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups/{backup_id}/verify")
async def verify_backup(backup_id: str) -> Dict[str, Any]:
    """Testa a conexão e a integridade com o destino remoto."""
    service = get_duplicati_native_service()
    result = service.verify_backup(backup_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result


@router.post("/backups/{backup_id}/compact")
async def compact_backup(backup_id: str) -> Dict[str, Any]:
    """Compacta e limpa blocos no destino remoto do backup."""
    service = get_duplicati_native_service()
    result = service.compact_backup(backup_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result)
    return result
