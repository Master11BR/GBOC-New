#!/usr/bin/env python3
"""GBOC 14.8.2 - Storage Usage & Growth Monitor API Router (Módulo Estrito)"""

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from typing import Optional

router = APIRouter(prefix="/api/v1/storage", tags=["Storage Monitor"])

@router.get("/usage")
async def get_current_usage():
    """Retorna o uso atual de todos os repositórios ativos e agregados por motor (Local e Destino)."""
    from engines.storage_monitor import get_storage_summary_by_engine
    summary = get_storage_summary_by_engine()
    return JSONResponse({"status": "success", "repositories": summary["repositories"], "by_engine": summary["by_engine"], "totals": summary["totals"]})

@router.get("/history")
async def get_history(days: int = 30, repository_id: Optional[str] = None):
    """Retorna o histórico de crescimento de armazenamento (até 90 dias)."""
    from engines.storage_monitor import get_storage_history
    # 0 = todo o histórico guardado (filtro de período dos gráficos)
    history = get_storage_history(repository_id=repository_id, days=36500 if days <= 0 else min(days, 3650))
    return JSONResponse({"status": "success", "history": history, "days": days})

@router.get("/config")
async def get_config():
    """Retorna configuração atual de alertas de armazenamento."""
    from engines.storage_monitor import get_storage_config
    return JSONResponse({"status": "success", "config": get_storage_config()})

@router.post("/config")
async def save_config(request: Request):
    """Salva configuração de alertas de armazenamento (threshold GB, crescimento %, intervalo de scan)."""
    body = await request.json()
    from engines.storage_monitor import save_storage_config
    saved = save_storage_config(body)
    return JSONResponse({"status": "success", "config": saved})

@router.post("/scan")
async def trigger_scan():
    """Força um scan imediato dos tamanhos de repositório."""
    from engines.storage_monitor import collect_repository_sizes
    data = collect_repository_sizes()
    return JSONResponse({"status": "success", "scanned": len(data), "repositories": data})
