# ==============================================================================
# GBOC System v14.8.2 Full Stable Enterprise Edition
# Copyright (c) 2026 Master11BR - Todos os direitos reservados.
# Propriedade Intelectual & Direitos Autorais Registrados.
# A cópia, distribuição ou modificação não autorizada é estritamente proibida.
# ==============================================================================

"""
GBOC Semantic Versioning 2.0 (SemVer) Control Module (Server)
Padronização Internacional de Versionamento: MAJOR.MINOR.PATCH-PRERELEASE+BUILD
Atualização e Rastreamento Dinâmico e Automático de Build / Revisão
"""

import os
import json
import subprocess
import datetime
import time
from typing import Dict, Any, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = os.path.join(BASE_DIR, "data", "version_info.json")

# Configuração Base SemVer
MAJOR = 14
MINOR = 8
PATCH = 2
PRERELEASE = "stable"

_GIT_INFO_CACHE: Optional[Dict[str, Any]] = None
_GIT_INFO_CACHE_TIME: float = 0.0
_GIT_INFO_TTL: float = 600.0  # renovado em segundo plano a cada 10 min

_BUILD_META_CACHE: Optional[Dict[str, Any]] = None
_BUILD_META_CACHE_TIME: float = 0.0
_BUILD_META_TTL: float = 30.0

_GIT_REFRESHING = False


def _get_git_info() -> Dict[str, Any]:
    """Informações do Git sem travar quem chama.

    Antes: a cada 60 s a primeira requisição (o cabeçalho de toda tela chama /api/system/info) executava
    4 comandos git dentro do servidor — no Windows, segundos com o servidor inteiro parado.
    Agora: a primeira leitura usa os valores padrão e o git roda numa thread; depois o valor fica em cache
    e é renovado em segundo plano (sem esperar)."""
    global _GIT_REFRESHING
    now = time.time()
    if _GIT_INFO_CACHE is None or (now - _GIT_INFO_CACHE_TIME) >= _GIT_INFO_TTL:
        if not _GIT_REFRESHING:
            _GIT_REFRESHING = True
            import threading as _th
            _th.Thread(target=_refresh_git_info, name="gboc-git-info", daemon=True).start()
    return _GIT_INFO_CACHE or {"commit": "a8f2e91", "commit_count": "1", "branch": "main", "is_dirty": False}


def _refresh_git_info() -> Dict[str, Any]:
    global _GIT_INFO_CACHE, _GIT_INFO_CACHE_TIME, _GIT_REFRESHING
    now = time.time()

    info = {
        "commit": "a8f2e91",
        "commit_count": "1",
        "branch": "main",
        "is_dirty": False
    }
    try:
        # Commit curto
        res = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                             cwd=BASE_DIR, capture_output=True, text=True, timeout=2)
        if res.returncode == 0 and res.stdout.strip():
            info["commit"] = res.stdout.strip()
        
        # Contagem de commits (revisão)
        res_count = subprocess.run(["git", "rev-list", "--count", "HEAD"],
                                   cwd=BASE_DIR, capture_output=True, text=True, timeout=2)
        if res_count.returncode == 0 and res_count.stdout.strip():
            info["commit_count"] = res_count.stdout.strip()
            
        # Branch
        res_branch = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                                    cwd=BASE_DIR, capture_output=True, text=True, timeout=2)
        if res_branch.returncode == 0 and res_branch.stdout.strip():
            info["branch"] = res_branch.stdout.strip()

        # Status modificado / dirty
        res_status = subprocess.run(["git", "status", "--porcelain"],
                                    cwd=BASE_DIR, capture_output=True, text=True, timeout=2)
        if res_status.returncode == 0 and res_status.stdout.strip():
            info["is_dirty"] = True
    except Exception:
        pass

    _GIT_INFO_CACHE = info
    _GIT_INFO_CACHE_TIME = now
    _GIT_REFRESHING = False
    return info

def _load_or_create_build_meta() -> Dict[str, Any]:
    """Carrega ou cria o estado persistente do build counter com cache TTL."""
    global _BUILD_META_CACHE, _BUILD_META_CACHE_TIME
    now = time.time()
    if _BUILD_META_CACHE is not None and (now - _BUILD_META_CACHE_TIME) < _BUILD_META_TTL:
        return _BUILD_META_CACHE

    os.makedirs(os.path.dirname(VERSION_FILE), exist_ok=True)
    today_str = datetime.date.today().strftime("%Y-%m-%d")
    
    data = {
        "build_number": 1,
        "last_build_date": today_str,
        "last_updated": datetime.datetime.now().isoformat()
    }
    
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    data.update(loaded)
        except Exception:
            pass
            
    _BUILD_META_CACHE = data
    _BUILD_META_CACHE_TIME = now
    return data

def auto_increment_build() -> int:
    """Incrementa o build counter persistente a cada nova alteração / inicialização."""
    global _BUILD_META_CACHE, _BUILD_META_CACHE_TIME
    meta = _load_or_create_build_meta()
    meta["build_number"] = int(meta.get("build_number", 0)) + 1
    meta["last_build_date"] = datetime.date.today().strftime("%Y-%m-%d")
    meta["last_updated"] = datetime.datetime.now().isoformat()
    try:
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
    except Exception:
        pass
    _BUILD_META_CACHE = meta
    _BUILD_META_CACHE_TIME = time.time()
    return meta["build_number"]

def bump_version(part: str = "patch") -> str:
    """Incrementa programaticamente partes da versão (major, minor, patch, build)."""
    global MAJOR, MINOR, PATCH
    if part == "major":
        MAJOR += 1
        MINOR = 0
        PATCH = 0
    elif part == "minor":
        MINOR += 1
        PATCH = 0
    elif part == "patch":
        PATCH += 1
    global _VERSION_INFO_CACHE
    _VERSION_INFO_CACHE = None
    auto_increment_build()
    return f"{MAJOR}.{MINOR}.{PATCH}"

_VERSION_INFO_CACHE: Optional[Dict[str, Any]] = None
_VERSION_INFO_CACHE_TIME: float = 0.0
_VERSION_INFO_TTL: float = 30.0

def get_version_info() -> Dict[str, Any]:
    """Retorna informações detalhadas e dinâmicas do versionamento semântico 2.0 (com cache de 30s)."""
    global _VERSION_INFO_CACHE, _VERSION_INFO_CACHE_TIME
    now = time.time()
    if _VERSION_INFO_CACHE is not None and (now - _VERSION_INFO_CACHE_TIME) < _VERSION_INFO_TTL:
        return dict(_VERSION_INFO_CACHE)

    git_info = _get_git_info()
    meta = _load_or_create_build_meta()
    
    build_num = meta.get("build_number", 1)
    build_date = meta.get("last_build_date", datetime.date.today().strftime("%Y-%m-%d"))
    git_sha = git_info["commit"]
    rev_count = git_info["commit_count"]
    dirty_tag = ".dirty" if git_info["is_dirty"] else ""
    
    raw_version = f"{MAJOR}.{MINOR}.{PATCH}"
    semver_str = f"{raw_version}-{PRERELEASE}+build.{build_date}.rev{rev_count}.b{build_num}.git.{git_sha}{dirty_tag}"
    
    res = {
        "raw_version": raw_version,
        "semver": semver_str,
        "major": MAJOR,
        "minor": MINOR,
        "patch": PATCH,
        "prerelease": PRERELEASE,
        "build_number": build_num,
        "build_date": build_date,
        "git_commit": git_sha,
        "git_branch": git_info["branch"],
        "git_revision": rev_count,
        "is_dirty": git_info["is_dirty"],
        "last_updated": meta.get("last_updated"),
        "release_channel": "Enterprise Stable",
        "compatibility": {
            "min_agent_version": "14.6.0",
            "recommended_agent_version": raw_version,
            "protocol_version": "2.1"
        }
    }
    _VERSION_INFO_CACHE = res
    _VERSION_INFO_CACHE_TIME = now
    return dict(res)

__version__ = f"{MAJOR}.{MINOR}.{PATCH}"
