// ==============================================================================
// GBOC System v14.8.2 Enterprise Edition
// Module: Config & IA & LLMs Controller (config.js)
// ==============================================================================

document.addEventListener('DOMContentLoaded', () => {
    loadServerAIConfigUI();
});

function switchConfigSubTab(sub, btn) {
    document.querySelectorAll('.cfg-subtab-pane').forEach(p => p.style.display = 'none');
    document.querySelectorAll('#srv-config-subtabs .tab-btn').forEach(b => b.classList.remove('active'));
    const target = document.getElementById('cfg-subtab-' + sub);
    if (target) target.style.display = 'block';
    if (btn) btn.classList.add('active');
    if (sub === 'ai') loadServerAIConfigUI();
}

async function loadServerAIConfigUI() {
    try {
        const r = await fetch(window.GBOC_API_BASE + '/api/v1/ai/config', { headers: _cfgAuthHeaders() });
        if (!r.ok) return;
        const data = await r.json();
        const cfg = data.config || {};
        
        if (document.getElementById('ai-provider')) document.getElementById('ai-provider').value = cfg.provider || 'ollama';
        if (document.getElementById('ai-ollama-host')) document.getElementById('ai-ollama-host').value = cfg.ollama_url || cfg.ollama_host || 'http://localhost:11434';
        if (document.getElementById('ai-model')) document.getElementById('ai-model').value = cfg.model || cfg.ollama_model || 'llama3';
        const keyEl = document.getElementById('ai-api-key');
        if (keyEl) {
            // Nunca preencher com a chave mascarada: em branco = manter a chave atual.
            keyEl.value = '';
            keyEl.placeholder = (cfg.configured_keys || []).length ? 'Chave já configurada — deixe em branco para manter' : 'Cole a chave de API';
        }
        if (document.getElementById('task-history-limit')) document.getElementById('task-history-limit').value = cfg.task_history_limit || 10;
        
        toggleAiFields();
        detectOllamaModels();
    } catch (e) {
        console.error('loadServerAIConfigUI error:', e);
    }
}

function toggleAiFields() {
    const provider = document.getElementById('ai-provider').value;
    const ollamaGroup = document.getElementById('group-ollama-host');
    const apiKeyGroup = document.getElementById('group-api-key');
    const modelInput = document.getElementById('ai-model');
    const apiKeyLinkDiv = document.getElementById('ai-api-key-link');

    const defaultModels = {
        ollama: 'qwen3.5:4b',
        kimi: 'kimi-k2.6',
        grok: 'grok-4.7',
        groq: 'openai/gpt-oss-120b',
        groq_free: 'openai/gpt-oss-120b',
        openai: 'gpt-4o-mini',
        gemini: 'gemini-flash-latest',
        deepseek: 'deepseek-flash',
        claude: 'claude-sonnet-5-5',
        qwen: 'qwen3.5:9b',
        mistral: 'mistral-large-latest',
        llama3: 'llama3.1:8b',
        cohere: 'command-a-plus-05-2026'
    };

    const providerKeyLinks = {
        deepseek: { url: 'https://platform.deepseek.com/api_keys', label: '🔗 Clique aqui para gerar sua API Key no portal DeepSeek (platform.deepseek.com/api_keys)' },
        openai: { url: 'https://platform.openai.com/api-keys', label: '🔗 Clique aqui para gerar sua API Key na OpenAI (platform.openai.com/api-keys)' },
        gemini: { url: 'https://aistudio.google.com/app/apikey', label: '🔗 Clique aqui para gerar sua API Key gratuita no Google AI Studio (aistudio.google.com)' },
        groq_free: { url: 'https://console.groq.com/keys', label: '🔗 Clique aqui para gerar sua API Key gratuita no Groq Cloud (console.groq.com/keys)' },
        claude: { url: 'https://platform.claude.com/settings/keys', label: '🔗 Clique aqui para gerar sua API Key da Anthropic (platform.claude.com)' },
        kimi: { url: 'https://platform.kimi.ai', label: '🔗 Clique aqui para gerar sua API Key no Kimi (platform.kimi.ai)' },
        grok: { url: 'https://console.x.ai/', label: '🔗 Clique aqui para gerar sua API Key no Grok xAI (console.x.ai)' },
        mistral: { url: 'https://console.mistral.ai/api-keys/', label: '🔗 Clique aqui para gerar sua API Key no Mistral AI (console.mistral.ai)' },
        cohere: { url: 'https://dashboard.cohere.com/api-keys', label: '🔗 Clique aqui para gerar sua API Key no Cohere (dashboard.cohere.com)' }
    };

    if (modelInput && defaultModels[provider]) {
        modelInput.placeholder = `Ex: ${defaultModels[provider]}`;
    }

    if (apiKeyLinkDiv) {
        const linkInfo = providerKeyLinks[provider];
        if (linkInfo) {
            apiKeyLinkDiv.innerHTML = `<a href="${linkInfo.url}" target="_blank" rel="noopener noreferrer" style="color:var(--primary,#4fa3e8);text-decoration:none;font-weight:600"><i class="fas fa-external-link-alt" style="margin-right:4px"></i> ${linkInfo.label}</a>`;
        } else {
            apiKeyLinkDiv.innerHTML = '';
        }
    }

    if (provider === 'ollama' || provider === 'qwen' || provider === 'llama3') {
        if (ollamaGroup) ollamaGroup.style.display = 'block';
        if (apiKeyGroup) apiKeyGroup.style.display = 'none';
    } else {
        if (ollamaGroup) ollamaGroup.style.display = 'none';
        if (apiKeyGroup) apiKeyGroup.style.display = 'block';
    }
}

const _cfgEsc = (v) => String(v ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
const _cfgAuthHeaders = (extra = {}) => {
    let token = '';
    try { token = localStorage.getItem('gboc_server_token') || ''; } catch { token = ''; }
    return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
};

let gInstalledModels = [];
// Reserva: a lista oficial vem da API do servidor (recommended_models)
let gRecommendedModels = ["qwen3.5:4b", "qwen3.5:9b", "gemma4:12b", "gpt-oss:20b", "qwen3.8:27b", "llama3.1:8b", "deepseek-r1:8b",
    "glm-5.3-flash:cloud", "deepseek-v4.1-flash:cloud", "kimi-k3:cloud", "gemma4:31b-cloud"];
window.gOllamaModelSizes = window.gOllamaModelSizes || {"qwen3.5:4b": "~6 GB", "gemma4:12b": "~11 GB", "qwen3.8:27b": "~28 GB"};

function updateModelDropdownUI(installed, recommended, currentVal) {
    const select = document.getElementById('ai-model-select');
    if (!select) return;
    gInstalledModels = installed || [];
    const recs = recommended || gRecommendedModels;

    let html = '';

    if (gInstalledModels.length > 0) {
        html += `<optgroup label="🟢 Modelos Instalados Localmente (Prontos para Diagnóstico)">`;
        gInstalledModels.forEach(m => {
            html += `<option value="${_cfgEsc(m)}">🟢 ${_cfgEsc(m)} (Instalado - Pronto)</option>`;
        });
        html += `</optgroup>`;
    }

    const availableNotInstalled = recs.filter(m => !gInstalledModels.includes(m));
    const _isCloud = m => /[:-]cloud$/i.test(m);
    const _size = m => (window.gOllamaModelSizes && window.gOllamaModelSizes[m]) ? ` - ${window.gOllamaModelSizes[m]}` : '';
    const _local = availableNotInstalled.filter(m => !_isCloud(m));
    const _cloud = availableNotInstalled.filter(_isCloud);
    if (_local.length > 0) {
        html += `<optgroup label="⚪ Modelos locais para baixar (rodam nesta máquina)">`;
        _local.forEach(m => {
            html += `<option value="${_cfgEsc(m)}">⚪ ${_cfgEsc(m)}${_size(m)} (não baixado)</option>`;
        });
        html += `</optgroup>`;
    }
    if (_cloud.length > 0) {
        html += `<optgroup label="☁️ Modelos na nuvem do Ollama (requer 'ollama signin')">`;
        _cloud.forEach(m => {
            html += `<option value="${_cfgEsc(m)}">☁️ ${_cfgEsc(m)} (não adicionado)</option>`;
        });
        html += `</optgroup>`;
    }

    select.innerHTML = html;

    const valToSet = currentVal || (gInstalledModels.length > 0 ? gInstalledModels[0] : recs[0]);
    select.value = valToSet;
    document.getElementById('ai-model').value = valToSet;
    onModelSelectChanged(valToSet);
}

function onModelSelectChanged(val) {
    document.getElementById('ai-model').value = val;
    const badge = document.getElementById('model-status-badge');
    if (!badge) return;

    if (gInstalledModels.includes(val)) {
        badge.style.cssText = 'font-size:0.83em;padding:6px 10px;border-radius:6px;background:rgba(72,187,120,0.15);color:#48bb78;border:1px solid rgba(72,187,120,0.3);margin-top:4px';
        badge.innerHTML = `<i class="fas fa-check-circle"></i> Modelo <strong>${val}</strong> está INSTALADO no Ollama e pronto para uso imediato!`;
    } else {
        badge.style.cssText = 'font-size:0.83em;padding:6px 10px;border-radius:6px;background:rgba(240,169,64,0.15);color:var(--warning);border:1px solid rgba(240,169,64,0.3);margin-top:4px';
        badge.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Modelo <strong>${val}</strong> NÃO ESTÁ INSTALADO.<br>${/[:-]cloud$/i.test(val) ? 'Modelo na nuvem do Ollama: antes, entre na conta com <code>ollama signin</code> no servidor.<br>' : ''}` +
            `<button type="button" class="btn btn-sm btn-primary" style="margin-top:6px;padding:4px 8px;font-size:0.85em" onclick="pullOllamaModel('${val}')"><i class="fas fa-download"></i> Instalar Modelo Automaticamente</button>`;
    }
}

async function pullOllamaModel(modelName) {
    const host = document.getElementById('ai-ollama-host').value || 'http://localhost:11434';
    const ok = window.gbocConfirm ? await window.gbocConfirm(`Deseja iniciar o download do modelo "${modelName}" no Ollama do Servidor?\nIsso será feito em segundo plano pelo servidor central.`, {
        title: 'Baixar Modelo Ollama (Server)',
        icon: 'fas fa-brain',
        type: 'primary',
        confirmText: 'Baixar Modelo'
    }) : confirm(`Deseja iniciar o download do modelo "${modelName}" no Ollama do Servidor?\nIsso será feito em segundo plano pelo servidor central.`);

    if(!ok) return;
    
    const btn = document.querySelector(`button[onclick="pullOllamaModel('${modelName}')"]`);
    if(btn) {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Iniciando Instalação...';
        btn.disabled = true;
    }
    
    try {
        const res = await fetch(window.GBOC_API_BASE + '/api/v1/ai/ollama/models/pull', {
            method: 'POST',
            headers: _cfgAuthHeaders({'Content-Type': 'application/json'}),
            body: JSON.stringify({host: host, model: modelName})
        });
        const data = await res.json();
        if(data.status === 'downloading' || data.status === 'success') {
            alert(`✅ Instalação iniciada em segundo plano no servidor!\n\nClique em "Detectar IA Local" em alguns instantes para conferir se a instalação terminou.`);
        } else {
            alert(`❌ Erro ao baixar o modelo: ${data.message || 'Erro desconhecido'}`);
        }
    } catch(e) {
        alert(`❌ Falha na comunicação com o servidor: ${e.message}`);
    } finally {
        if(btn) {
            btn.innerHTML = '<i class="fas fa-download"></i> Instalar Modelo Automaticamente';
            btn.disabled = false;
        }
    }
}

async function detectOllamaModels() {
    const host = document.getElementById('ai-ollama-host').value || 'http://localhost:11434';
    const currentModel = document.getElementById('ai-model').value;
    const select = document.getElementById('ai-model-select');
    if (select) {
        select.innerHTML = '<option value="">Buscando no host...</option>';
    }

    try {
        const r = await fetch(window.GBOC_API_BASE + `/api/v1/ai/ollama/models?host=${encodeURIComponent(host)}`, { headers: _cfgAuthHeaders() });
        const data = await r.json();
        
        if (data.model_sizes) window.gOllamaModelSizes = data.model_sizes;
        const recs = (Array.isArray(data.recommended_models) && data.recommended_models.length) ? data.recommended_models : gRecommendedModels;
        if (data.connected && data.installed_models) {
            updateModelDropdownUI(data.installed_models, recs, currentModel);
        } else {
            updateModelDropdownUI([], recs, currentModel);
        }
    } catch (e) {
        console.error('Falha ao detectar modelos:', e);
        updateModelDropdownUI([], gRecommendedModels, currentModel);
    }
}

async function testAiConnection() {
    const btn = document.getElementById('btn-test-ai');
    const ogHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testando...';
    btn.disabled = true;

    // Remove old message
    const oldMsg = document.getElementById('cfg-ai-msg-toast');
    if(oldMsg) oldMsg.remove();

    try {
        const provider = document.getElementById('ai-provider').value;
        const host = document.getElementById('ai-ollama-host').value;
        const api_key = document.getElementById('ai-api-key').value;
        const model = document.getElementById('ai-model').value;

        // Save temporarily to backend config to test
        await saveAiSettings(true); 

        const r = await fetch(window.GBOC_API_BASE + '/api/v2/ai/diagnose', {
            method: 'POST',
            headers: _cfgAuthHeaders({'Content-Type':'application/json'}),
            body: JSON.stringify({error_context: 'Teste de conexão configurada.', provider: provider})
        });
        
        const resData = await r.json();
        const data = resData.data || resData;
        const msgDiv = document.createElement('div');
        msgDiv.id = 'cfg-ai-msg-toast';
        msgDiv.style.marginTop = '15px';
        msgDiv.style.padding = '12px 16px';
        msgDiv.style.borderRadius = '8px';
        msgDiv.style.fontSize = '0.9em';

        if (data.result && data.result.is_llm_real) {
            msgDiv.style.backgroundColor = 'rgba(72,187,120,0.15)';
            msgDiv.style.color = '#48bb78';
            msgDiv.style.border = '1px solid rgba(72,187,120,0.3)';
            msgDiv.innerHTML = `<i class="fas fa-check-circle"></i> Conexão bem sucedida com <strong>${provider}</strong>!<br><span style="font-size:0.85em;opacity:0.8;display:block;margin-top:6px">${_cfgEsc(data.result.analysis)}</span>`;
        } else {
            msgDiv.style.backgroundColor = 'rgba(245,101,101,0.15)';
            msgDiv.style.color = 'var(--danger)';
            msgDiv.style.border = '1px solid rgba(245,101,101,0.3)';
            msgDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Falha na conexão.<br><span style="font-size:0.85em;opacity:0.8;display:block;margin-top:6px">${_cfgEsc(data.result?.analysis || data.error?.message || data.detail || data.message || 'Erro desconhecido.')}</span>`;
        }
        document.getElementById('cfg-subtab-ai').querySelector('.panel').appendChild(msgDiv);
    } catch(e) {
        alert('Erro ao testar IA: ' + e.message);
    } finally {
        btn.innerHTML = ogHtml;
        btn.disabled = false;
    }
}

async function saveAiSettings(silent=false) {
    const btn = document.getElementById('btn-save-ai');
    const ogHtml = btn.innerHTML;
    if(!silent) {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';
        btn.disabled = true;
    }

    const provider = document.getElementById('ai-provider').value;
    const model = document.getElementById('ai-model').value.trim();
    const key = document.getElementById('ai-api-key').value.trim();
    const isLocal = ['ollama', 'qwen', 'llama3'].includes(provider);
    const cfg = {
        provider,
        ollama_url: document.getElementById('ai-ollama-host').value.trim(),
        task_history_limit: parseInt(document.getElementById('task-history-limit').value || '10', 10)
    };
    if (model) {
        cfg.model = model;
        if (isLocal) cfg.ollama_model = model;
        else cfg[`${provider === 'groq_free' ? 'groq' : provider}_model`] = model;
    }
    if (!isLocal && key) cfg.api_key = key;   // o backend grava no campo do provedor selecionado

    try {
        const r = await fetch(window.GBOC_API_BASE + '/api/v1/ai/config', {
            method: 'POST',
            headers: _cfgAuthHeaders({'Content-Type':'application/json'}),
            body: JSON.stringify(cfg)
        });
        if (!r.ok) {
            const d = await r.json().catch(() => ({}));
            throw new Error(d.message || d.detail || `HTTP ${r.status}`);
        }
        if(!silent) {
            alert('Configuração de IA salva com sucesso!');
        }
    } catch(e) {
        if(!silent) alert('Erro ao salvar IA: ' + e.message);
    } finally {
        if(!silent) {
            btn.innerHTML = ogHtml;
            btn.disabled = false;
        }
    }
}
